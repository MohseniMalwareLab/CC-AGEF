"""CC-AGEF end-to-end benchmark orchestrator.

Stages (subcommands):
  discover     - verify dataset artifacts are found
  build-index  - SQLite FTS/symbol index + dense embedding index
  retrieve     - run all retrieval systems on a split, write TREC run files
  evaluate     - score runs against the three qrels tiers per EVAL_PROTOCOL
  localize     - retrieval-derived localization vs gold references (Table 3)
  generate     - evidence-conditioned generation + closed-book baseline
  gen-eval     - citation/abstention metrics over generation outputs
  all          - build-index + retrieve + evaluate + localize

Typical Colab flow:
  python -m ccagef_bench.run_benchmark all \
      --root /content/drive/MyDrive/RAG/cc_agef_x86_dataset \
      --work /content/ccagef_work --split test
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .config import BenchConfig, discover_artifacts, require
from . import data as D
from .indexing.sqlite_index import SqliteEvidenceIndex
from .indexing.dense_index import DenseIndex, make_encoder
from .retrieval import retrievers as R
from .eval import protocol as P
from .eval.localization import predictions_from_run, localization_metrics
from .eval.stats import mean_with_ci
from .generation.harness import build_prompt, parse_output
from .generation.metrics import citation_metrics, abstention_metrics

Run = Dict[str, List[Tuple[str, float]]]

SYSTEMS_ORDER = ["r_symbol", "r_bm25", "r_dense", "r_channel",
                 "rrf_fusion", "rrf_no_symbol",
                 "rrf_graph_expand", "rrf_graph_rerank",
                 "rrf_graph_expand_rerank",
                 "rrf_graph_expand_nofilter"]


# ------------------------------------------------------------------ helpers -

def _load_cfg(args) -> BenchConfig:
    cfg = BenchConfig(dataset_root=args.root, work_dir=args.work)
    if getattr(args, "config", None):
        overrides = json.loads(Path(args.config).read_text())
        for k, v in overrides.items():
            if hasattr(cfg, k):
                setattr(cfg, k, v)
    for k in ("embed_model", "split", "limit", "generator_model"):
        v = getattr(args, k.replace("-", "_"), None)
        if v is not None:
            setattr(cfg, k, v)
    Path(cfg.work_dir).mkdir(parents=True, exist_ok=True)
    (Path(cfg.work_dir) / "config_used.json").write_text(cfg.to_json())
    return cfg


def _split_ids(art: Dict[str, str], cfg: BenchConfig) -> List[str]:
    key = {"train": "train_ids", "validation": "validation_ids",
           "test": "test_ids"}[cfg.split]
    ids = D.load_split_ids(art[key])
    return ids[:cfg.limit] if cfg.limit else ids


def _dense_name(cfg: BenchConfig) -> str:
    """Per-embedder index name so code/text embedders coexist in one work
    dir. The historical default model keeps the legacy name 'dense'."""
    if cfg.embed_model == "BAAI/bge-base-en-v1.5":
        return "dense"
    return "dense_" + "".join(
        ch if ch.isalnum() else "_" for ch in cfg.embed_model)[-48:]


LOCAL_DB_CACHE = Path("/tmp/ccagef_localdb")


def _is_fuse_path(p: Path) -> bool:
    return "/drive/" in str(p)                     # Google Drive FUSE mount


def _db_paths(cfg: BenchConfig) -> tuple:
    """(canonical, working). SQLite must not run over the Drive FUSE mount
    (locking/sync are unreliable there), so when the work dir is on Drive
    the canonical file is treated as storage and a VM-local copy is the
    working database."""
    canonical = Path(cfg.work_dir) / "evidence.sqlite"
    if _is_fuse_path(canonical):
        return canonical, LOCAL_DB_CACHE / "evidence.sqlite"
    return canonical, canonical


def _open_index(cfg: BenchConfig) -> SqliteEvidenceIndex:
    """Open the evidence index, staging a local copy when the work dir is on
    Drive, and failing loudly and helpfully when the index isn't built."""
    import shutil
    canonical, working = _db_paths(cfg)
    if canonical != working:
        c_size = canonical.stat().st_size if canonical.exists() else 0
        w_size = working.stat().st_size if working.exists() else 0
        if c_size > 0 and w_size != c_size:
            working.parent.mkdir(parents=True, exist_ok=True)
            print(f"staging evidence.sqlite from Drive to VM disk "
                  f"({c_size/1e9:.2f} GB) ...")
            shutil.copyfile(canonical, working)
        elif c_size == 0 and w_size > 0:
            print("NOTE: using VM-local evidence.sqlite (Drive copy "
                  "missing/empty — run the 'Save indexes' step to persist)")
        working.parent.mkdir(parents=True, exist_ok=True)
    idx = SqliteEvidenceIndex(str(working))
    if not idx.is_built():
        c_info = "missing"
        if canonical.exists():
            c_info = f"{canonical.stat().st_size/1e9:.2f} GB on disk"
        raise SystemExit(
            f"\nERROR: evidence index unusable.\n"
            f"  canonical: {canonical} ({c_info})\n"
            f"  working:   {working}\n"
            "If the canonical file exists but is unreadable, it is most\n"
            "likely an incomplete Drive sync of an interrupted build.\n"
            "Rebuild (writes locally, then copies the finished DB to the\n"
            "work dir; the dense index is separate and reused):\n\n"
            f"  python -m ccagef_bench.run_benchmark build-index \\\n"
            f"      --root <DATASET_ROOT> --work {cfg.work_dir} --skip-dense")
    return idx


def _write_trec_run(run: Run, path: str, tag: str) -> None:
    with open(path, "w") as fh:
        for qid, ranked in run.items():
            for rank, (docid, score) in enumerate(ranked, 1):
                fh.write(f"{qid}\tQ0\t{docid}\t{rank}\t{score:.6f}\t{tag}\n")


def _read_trec_run(path: str) -> Run:
    run: Run = {}
    with open(path) as fh:
        for ln in fh:
            parts = ln.rstrip("\n").split("\t")
            if len(parts) < 6:
                parts = ln.split()
            qid, _q0, docid, _rank, score = parts[0], parts[1], parts[2], \
                parts[3], float(parts[4])
            run.setdefault(qid, []).append((docid, score))
    for qid in run:
        run[qid].sort(key=lambda x: -x[1])
    return run


# ------------------------------------------------------------------- stages -

def stage_discover(args) -> None:
    cfg = _load_cfg(args)
    art = discover_artifacts(cfg.dataset_root)
    print(json.dumps(art, indent=2))
    missing = [k for k in ("samples_public", "evidence", "strict_qrels",
                           "silver_qrels", "gold_qrels", "test_ids")
               if k not in art]
    print("MISSING (required):", missing or "none — dataset looks complete")


def stage_build_index(args) -> None:
    cfg = _load_cfg(args)
    art = discover_artifacts(cfg.dataset_root)
    require(art, ["evidence"])
    t0 = time.time()
    canonical, working = _db_paths(cfg)
    if canonical != working:
        working.parent.mkdir(parents=True, exist_ok=True)
        if working.exists():
            working.unlink()                       # never build over stale copy
        print(f"work dir is on Drive — building SQLite locally at {working}, "
              "will copy the finished DB back")
    idx = SqliteEvidenceIndex(str(working))
    idx.build(art["evidence"], art.get("code_symbol_index"))
    if canonical != working:
        import shutil
        idx.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        idx.conn.commit()
        print(f"copying finished DB to Drive "
              f"({working.stat().st_size/1e9:.2f} GB) ...")
        shutil.copyfile(working, canonical)
        if canonical.stat().st_size != working.stat().st_size:
            print("WARNING: Drive copy size mismatch — rerun the copy or "
                  "keep using the VM-local DB this session")
    print(f"sqlite index: {time.time()-t0:.0f}s")
    if not args.skip_dense:
        dense = DenseIndex(cfg.work_dir, name=_dense_name(cfg))
        if dense.exists() and not args.force:
            print("dense index already present — use --force to rebuild")
        else:
            enc = make_encoder(cfg.embed_model, cfg.embed_fp16)
            dense.build(enc, idx.iter_texts(cfg.embed_max_chars),
                        batch_size=cfg.embed_batch_size,
                        total_hint=idx.count())
            # Self-retrieval sanity check: querying with a chunk's own text
            # must return that chunk near the top. A broken encoder (wrong
            # architecture, garbage weights) fails this decisively; a real
            # one passes trivially. Guards against silently poisoned runs.
            import random as _rnd
            dense.load()
            sample = [(eid, txt) for i, (eid, txt) in
                      enumerate(idx.iter_texts(cfg.embed_max_chars))
                      if i % max(1, idx.count() // 20) == 0][:20]
            hits = 0
            for eid, txt in sample:
                top = dense.search(enc, txt, top_k=5)
                if any(e == eid for e, _s in top):
                    hits += 1
            rate = hits / max(len(sample), 1)
            print(f"self-retrieval check: {hits}/{len(sample)} "
                  f"({rate:.0%}) chunks retrieve themselves in top-5")
            if rate < 0.6:
                # remove the poisoned index so nothing downstream uses it
                for f in (dense._vec_path, dense._ids_path):
                    if f.exists():
                        f.unlink()
                raise SystemExit(
                    f"\nERROR: dense index FAILED the self-retrieval check "
                    f"({rate:.0%} < 60%).\nThe encoder '{cfg.embed_model}' "
                    "is producing unusable embeddings (typically a custom "
                    "architecture loaded without its remote code).\nThe "
                    "broken index has been deleted. Use a standard-"
                    "architecture code embedder instead, e.g.:\n"
                    "  --embed-model jinaai/jina-code-embeddings-0.5b")
    print(f"build-index done in {time.time()-t0:.0f}s")


def stage_retrieve(args) -> None:
    cfg = _load_cfg(args)
    art = discover_artifacts(cfg.dataset_root)
    require(art, ["samples_public", "evidence"])
    qids = _split_ids(art, cfg)
    samples = D.load_samples(art["samples_public"], set(qids))
    qids = [q for q in qids if q in samples]
    print(f"retrieving for {len(qids)} queries on split={cfg.split}")

    idx = _open_index(cfg)
    dense = DenseIndex(cfg.work_dir, name=_dense_name(cfg))
    encoder = None
    if dense.exists():
        dense.load()
        encoder = make_encoder(cfg.embed_model, cfg.embed_fp16)
    else:
        if getattr(args, "tag", None):
            raise SystemExit(
                f"\nERROR: refusing to write '--tag {args.tag}' runs: the "
                f"dense index for --embed-model {cfg.embed_model} is not "
                "built.\nTagged runs exist for embedder ablations; writing "
                "them with a degraded dense channel would silently poison "
                "the ablation table.\nRun build-index with the same "
                "--embed-model first, then retry.")
        print("WARNING: dense index missing — r_dense/r_channel degrade to "
              "lexical only")

    graph = None
    frame_res: Dict[str, List[dict]] = {}
    if all(k in art for k in ("edges", "evidence_to_node")):
        print("loading evidence graph ...")
        graph = D.EvidenceGraph.load(art["edges"], art["evidence_to_node"],
                                     art.get("nodes"))
        if "frame_resolution" in art:
            frame_res = D.load_frame_resolution(art["frame_resolution"])
        print(f"graph: {len(graph.name_of):,} nodes")

    evidence_nodes: Dict[str, str] = {}
    if graph is not None:
        cur = idx.conn.execute(
            "SELECT evidence_id, entity_node_id FROM evidence "
            "WHERE entity_node_id != ''")
        evidence_nodes = dict(cur.fetchall())

    systems: Dict[str, Run] = {name: {} for name in SYSTEMS_ORDER}
    t0 = time.time()
    for n, qid in enumerate(qids, 1):
        s = samples[qid]
        rs = R.r_symbol(s, idx, cfg)
        rb = R.r_bm25(s, idx, cfg)
        rd = R.r_dense(s, dense, encoder, cfg) if encoder else []
        rc = R.r_channel(s, idx, dense if encoder else None, encoder, cfg) \
            if True else []
        fused = R.rrf([rs, rb, rd, rc], k=cfg.rrf_k)[:cfg.top_k_retrieve]
        # ablation (code-centricity): fusion WITHOUT the code-aware symbol
        # channel — the delta vs rrf_fusion isolates symbol retrieval.
        no_sym = R.rrf([rb, rd, rc], k=cfg.rrf_k)[:cfg.top_k_retrieve]
        systems["r_symbol"][qid] = rs
        systems["r_bm25"][qid] = rb
        systems["r_dense"][qid] = rd
        systems["r_channel"][qid] = rc
        systems["rrf_fusion"][qid] = fused
        systems["rrf_no_symbol"][qid] = no_sym
        if graph is not None:
            ge = R.graph_expand_run(fused, qid, graph, frame_res, cfg)
            gr = R.graph_rerank_run(fused, qid, graph, frame_res,
                                    evidence_nodes, cfg)
            ger = R.graph_rerank_run(ge, qid, graph, frame_res,
                                     evidence_nodes, cfg)
            systems["rrf_graph_expand"][qid] = ge
            systems["rrf_graph_rerank"][qid] = gr
            systems["rrf_graph_expand_rerank"][qid] = ger
            # ablation (code-centricity): graph seeding WITHOUT the
            # code-aware frame filters (generic frames + implausible paths)
            import copy as _copy
            cfg_nf = _copy.copy(cfg)
            cfg_nf.filter_generic_frames = False
            cfg_nf.filter_implausible_paths = False
            systems["rrf_graph_expand_nofilter"][qid] = R.graph_expand_run(
                fused, qid, graph, frame_res, cfg_nf)
        if n % 25 == 0 or n == len(qids):
            print(f"  {n}/{len(qids)} queries "
                  f"({(time.time()-t0)/n:.2f}s/q)")

    if not args.skip_rerank:
        try:
            from .retrieval.rerank import CrossEncoderReranker
            rr = CrossEncoderReranker(cfg.reranker_model)
            reranked: Run = {}
            for qid in qids:
                base = systems["rrf_graph_expand"].get(qid) or \
                    systems["rrf_fusion"][qid]
                texts = idx.get_texts([e for e, _ in base[:cfg.rerank_depth]])
                dq = samples[qid].get("input", {}).get("query_views", {}) \
                    .get("dense_query", "")[:1000]
                reranked[qid] = rr.rerank(dq, base, texts, cfg.rerank_depth)
            systems["rrf_graph_expand_ce"] = reranked
        except Exception as e:
            print(f"reranker unavailable ({e}) — skipping CE rerank system")

    run_dir = Path(cfg.work_dir) / "runs" / cfg.split
    run_dir.mkdir(parents=True, exist_ok=True)
    suffix = f"__{args.tag}" if getattr(args, "tag", None) else ""
    for name, run in systems.items():
        if run:
            _write_trec_run(run, str(run_dir / f"{name}{suffix}.trec"),
                            name + suffix)
    print(f"wrote {len([r for r in systems.values() if r])} run files "
          f"-> {run_dir}")


def stage_evaluate(args) -> None:
    cfg = _load_cfg(args)
    art = discover_artifacts(cfg.dataset_root)
    require(art, ["strict_qrels", "silver_qrels", "gold_qrels"])
    run_dir = Path(cfg.work_dir) / "runs" / cfg.split
    run_files = sorted(run_dir.glob("*.trec"))
    if not run_files:
        raise SystemExit(f"no run files in {run_dir} — run `retrieve` first")
    systems: Dict[str, Run] = {p.stem: _read_trec_run(str(p))
                               for p in run_files}
    qids_all = _split_ids(art, cfg)
    families = D.load_families(art.get("samples_internal"), qids_all)
    filters = D.load_eval_filters(art["eval_filters"]) \
        if "eval_filters" in art else {}

    tiers = {"strict": D.load_qrels(art["strict_qrels"]),
             "silver": D.load_qrels(art["silver_qrels"]),
             "gold": D.load_qrels(art["gold_qrels"])}

    # protocol §3: retrieval-eligible = has >=1 graded row in ANY tier;
    # no-qrels samples go to the abstention track, not here.
    eligible = [q for q in qids_all
                if any(q in t and t[q] for t in tiers.values())]
    ungrounded = sorted(set(qids_all) - set(eligible))
    out_dir = Path(cfg.work_dir) / "results" / cfg.split
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "abstention_track_qids.json").write_text(
        json.dumps(ungrounded, indent=2))
    print(f"eligible queries: {len(eligible)}/{len(qids_all)} "
          f"({len(ungrounded)} routed to abstention track)")

    for tier, qrels in tiers.items():
        tier_qids = [q for q in eligible if q in qrels and qrels[q]]
        per_sys_pq: Dict[str, Dict[str, Dict[str, Optional[float]]]] = {}
        summaries: Dict[str, Dict[str, dict]] = {}
        for name, run in systems.items():
            pq = P.evaluate_run_on_tier(run, qrels, tier, cfg, tier_qids)
            per_sys_pq[name] = pq
            summaries[name] = P.summarize(pq, families, cfg)
        sig = {}
        headline = (f"Recall@{max(cfg.recall_ks)}"
                    if tier in ("strict", "silver")
                    else f"nDCG@{cfg.ndcg_k}")
        for baseline in ("rrf_fusion", "r_symbol"):
            if baseline in per_sys_pq:
                sig[f"{headline}_vs_{baseline}"] = P.significance_vs_baseline(
                    per_sys_pq, baseline, headline, families, cfg)
        path = P.write_report(str(out_dir), tier, summaries, sig)
        print(f"[{tier}] {len(tier_qids)} queries -> {path}")
    print(f"results in {out_dir}")


def stage_localize(args) -> None:
    cfg = _load_cfg(args)
    art = discover_artifacts(cfg.dataset_root)
    require(art, ["references_gold"])
    refs = D.load_references(art["references_gold"])
    qids = _split_ids(art, cfg)
    families = D.load_families(art.get("samples_internal"), qids)
    idx = _open_index(cfg)
    run_dir = Path(cfg.work_dir) / "runs" / cfg.split
    out_dir = Path(cfg.work_dir) / "results" / cfg.split
    out_dir.mkdir(parents=True, exist_ok=True)
    summaries: Dict[str, Dict[str, dict]] = {}
    for p in sorted(run_dir.glob("*.trec")):
        run = _read_trec_run(str(p))
        pq: Dict[str, Dict[str, Optional[float]]] = {}
        for qid in qids:
            if qid not in refs or qid not in run:
                continue
            ranked = [d for d, _s in run[qid]]
            texts = idx.get_texts(ranked[:20])
            pred = predictions_from_run(ranked, texts, top_k=10)
            for m, v in localization_metrics(pred, refs[qid]).items():
                pq.setdefault(m, {})[qid] = v
        summaries[p.stem] = {m: dict(zip(
            ("mean", "ci_low", "ci_high", "n_families"),
            mean_with_ci(vals, families, cfg.bootstrap_resamples,
                         cfg.bootstrap_seed)))
            for m, vals in pq.items()}
    P.write_report(str(out_dir), "localization", summaries)
    print(f"localization table -> {out_dir}/table_localization.csv")


def stage_generate(args) -> None:
    cfg = _load_cfg(args)
    art = discover_artifacts(cfg.dataset_root)
    qids = _split_ids(art, cfg)
    samples = D.load_samples(art["samples_public"], set(qids))
    idx = _open_index(cfg)
    run_dir = Path(cfg.work_dir) / "runs" / cfg.split
    run_path = run_dir / f"{args.run_name}.trec"
    run = _read_trec_run(str(run_path)) if run_path.exists() else {}
    graph = frame_res = None
    if not args.closed_book and all(k in art for k in
                                    ("edges", "evidence_to_node")):
        graph = D.EvidenceGraph.load(art["edges"], art["evidence_to_node"])
        frame_res = D.load_frame_resolution(art["frame_resolution"]) \
            if "frame_resolution" in art else {}

    from .generation.harness import make_generator
    gen = make_generator(cfg.generator_model, cfg.generator_4bit,
                         cfg.generator_max_new_tokens)
    tag = "closedbook" if args.closed_book else f"rag_{args.run_name}"
    out_path = Path(cfg.work_dir) / "results" / cfg.split / f"gen_{tag}.jsonl"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as fh:
        for n, qid in enumerate(qids, 1):
            if qid not in samples:
                continue
            s = samples[qid]
            if args.closed_book:
                prompt = build_prompt(s, [], [], closed_book=True)
            else:
                ranked = [d for d, _sc in run.get(qid, [])][:cfg.evidence_top_k]
                texts = idx.get_texts(ranked)
                ev = [texts[e] for e in ranked if e in texts]
                paths = R.top_graph_paths(qid, graph, frame_res, cfg) \
                    if graph else []
                prompt = build_prompt(s, ev, paths,
                                      char_budget=cfg.evidence_char_budget)
            raw = gen.generate(prompt)
            rec = {"sample_id": qid, "output": parse_output(raw)}
            fh.write(json.dumps(rec) + "\n")
            if n % 10 == 0:
                print(f"  generated {n}/{len(qids)}")
    print(f"generation outputs -> {out_path}")


def stage_gen_eval(args) -> None:
    cfg = _load_cfg(args)
    art = discover_artifacts(cfg.dataset_root)
    gold = D.load_qrels(art["gold_qrels"])
    idx = _open_index(cfg)
    corpus_ids = {i for i, _c in idx.all_ids_channels()}
    # Citation normalizer: generators frequently drop the leading channel
    # prefix ("code:ffc..." -> "ffc..."). Recover deterministically via a
    # channel-stripped suffix map; anything unrecoverable stays as-is and is
    # scored hallucinated. Report the recovery rate for transparency.
    suffix_map: Dict[str, str] = {}
    for cid in corpus_ids:
        sfx = cid.split(":", 1)[1] if ":" in cid else cid
        suffix_map.setdefault(sfx, cid)

    def normalize_citation(c: str) -> str:
        c = c.strip().strip("[]").strip()
        if c in corpus_ids:
            return c
        return suffix_map.get(c, c)
    qids = _split_ids(art, cfg)
    tiers = {"strict": D.load_qrels(art["strict_qrels"]), "gold": gold}
    ungrounded = {q for q in qids
                  if not any(q in t and t[q] for t in tiers.values())}
    families = D.load_families(art.get("samples_internal"), qids)
    res_dir = Path(cfg.work_dir) / "results" / cfg.split
    summaries: Dict[str, Dict[str, dict]] = {}
    for gen_file in sorted(res_dir.glob("gen_*.jsonl")):
        results = {r["sample_id"]: r["output"]
                   for r in D.iter_jsonl(str(gen_file))}
        pq: Dict[str, Dict[str, Optional[float]]] = {}
        n_cites = n_recovered = 0
        for qid, out in results.items():
            if out.get("abstain") or out.get("parse_error"):
                continue
            raw_cites = out.get("citations", [])
            cites = [normalize_citation(c) for c in raw_cites]
            n_cites += len(raw_cites)
            n_recovered += sum(1 for r, c in zip(raw_cites, cites)
                               if c != r and c in corpus_ids)
            cm = citation_metrics(cites,
                                  gold.get(qid, {}), corpus_ids,
                                  cfg.gold_relevant_min_grade)
            for m, v in cm.items():
                pq.setdefault(m, {})[qid] = v
        summaries[gen_file.stem] = {m: dict(zip(
            ("mean", "ci_low", "ci_high", "n_families"),
            mean_with_ci(vals, families, cfg.bootstrap_resamples,
                         cfg.bootstrap_seed))) for m, vals in pq.items()}
        if n_cites:
            print(f"  {gen_file.stem}: normalized {n_recovered}/{n_cites} "
                  f"channel-dropped citations")
        ab = abstention_metrics(results, ungrounded)
        summaries[gen_file.stem].update(
            {m: {"mean": v, "ci_low": None, "ci_high": None,
                 "n_families": None} for m, v in ab.items()})
    P.write_report(str(res_dir), "generation", summaries)
    print(f"generation metrics -> {res_dir}/table_generation.csv")


# ---------------------------------------------------------------------------
# Single-method benchmark: one baseline end-to-end, generation metrics at the
# end. Strict + gold only (per protocol directive; silver untouched here).
# ---------------------------------------------------------------------------
CODE_ENCODER_MODEL = "jinaai/jina-code-embeddings-0.5b"

# Encoder registry: key -> (HF model id, run-name suffix).
ENCODERS = {
    "code":     (CODE_ENCODER_MODEL,             "__codeemb"),
    "coderank": ("nomic-ai/CodeRankEmbed",       "__coderank"),
    "swerank":  ("Salesforce/SweRankEmbed-Small", "__swerank"),
}

# method -> (base system, encoder key or None, description)
METHODS = {
    "sym":         ("r_symbol",   None, "Base R_sym (exact symbol lookup)"),
    "bm25":        ("r_bm25",     None, "Base BM25"),
    "dense":       ("r_dense",    None, "Base dense retriever (text enc.)"),
    "channel":     ("r_channel",  None, "Base per-channel retriever"),
    "fusion":      ("rrf_fusion", None, "Flat RRF fusion baseline"),
    "codedense":   ("r_dense",    "code",
                    "External: learned code retriever (Jina-code 0.5B)"),
    "coderank":    ("r_dense",    "coderank",
                    "External: CodeRankEmbed (CoRNStack, 137M)"),
    "swerank":     ("r_dense",    "swerank",
                    "External: SweRankEmbed-Small (SweRank, 137M)"),
    "expand":      ("rrf_graph_expand", None, "Ablation: +graph expand"),
    "rerank":      ("rrf_graph_rerank", None, "Ablation: +graph rerank"),
    "ccagef":      ("rrf_graph_expand_rerank", None, "Ours: CC-AGEF"),
    "ccagef-code": ("rrf_graph_expand_rerank", "code",
                    "Ours: CC-AGEF + code encoder"),
    "vanilla":     ("__closedbook__", None,
                    "Vanilla LLM (closed-book, no retrieval)"),
}

GOLD_METRICS = ("nDCG@10", "P@10", "bpref", "MRR", "Unjudged@10")
STRICT_METRICS = ("Recall@100", "RPrec", "nDCG@10")


def _retrieve_one_system(cfg, art, idx, dense, enc, base_system, qids,
                         samples):
    """Produce the ranked run for exactly one system (plus its dependencies
    computed transiently, never written)."""
    need_graph = base_system.startswith("rrf_graph")
    graph = frame_res = ev_nodes = None
    if need_graph:
        graph = D.EvidenceGraph.load(art["edges"], art["evidence_to_node"])
        frame_res = D.load_frame_resolution(art["frame_resolution"]) \
            if "frame_resolution" in art else {}
        cur = idx.conn.execute(
            "SELECT evidence_id, entity_node_id FROM evidence "
            "WHERE entity_node_id != ''")
        ev_nodes = dict(cur.fetchall())
    run: Dict[str, list] = {}
    for n, qid in enumerate(qids, 1):
        if qid not in samples:
            continue
        s_ = samples[qid]
        if base_system == "r_symbol":
            ranked = R.r_symbol(s_, idx, cfg)
        elif base_system == "r_bm25":
            ranked = R.r_bm25(s_, idx, cfg)
        elif base_system == "r_dense":
            ranked = R.r_dense(s_, dense, enc, cfg)
        elif base_system == "r_channel":
            ranked = R.r_channel(s_, idx, dense, enc, cfg)
        else:                       # fusion family
            base = [R.r_symbol(s_, idx, cfg), R.r_bm25(s_, idx, cfg),
                    R.r_dense(s_, dense, enc, cfg),
                    R.r_channel(s_, idx, dense, enc, cfg)]
            ranked = R.rrf(base)
            if base_system in ("rrf_graph_expand",
                               "rrf_graph_expand_rerank"):
                ranked = R.graph_expand_run(ranked, qid, graph, frame_res,
                                            cfg)
            if base_system in ("rrf_graph_rerank",
                               "rrf_graph_expand_rerank"):
                ranked = R.graph_rerank_run(ranked, qid, graph, frame_res,
                                            ev_nodes, cfg)
        run[qid] = ranked[:cfg.top_k_retrieve]
        if n % 50 == 0:
            print(f"  retrieved {n}/{len(qids)}")
    return run


def stage_run_method(args) -> None:
    """One baseline, end to end: retrieve -> strict+gold retrieval metrics ->
    generate over its evidence -> generation metrics. Run once per method."""
    import csv as _csv
    if args.method not in METHODS:
        raise SystemExit(f"--method must be one of {sorted(METHODS)}")
    base_system, enc_key, desc = METHODS[args.method]
    cfg = _load_cfg(args)
    suffix = ""
    if enc_key is not None:
        cfg.embed_model, suffix = ENCODERS[enc_key]
    art = discover_artifacts(cfg.dataset_root)
    require(art, ["samples_public", "strict_qrels", "gold_qrels",
                  "references_gold"])
    qids = _split_ids(art, cfg)
    samples = D.load_samples(art["samples_public"], set(qids))
    idx = _open_index(cfg)

    closed_book = base_system == "__closedbook__"
    run_name = "closedbook" if closed_book else base_system + suffix
    print(f"=== run-method: {args.method} -> {run_name} ({desc})")

    # ---- dense index availability (never auto-build: it costs ~an hour) ---
    dense = enc = None
    needs_dense = (not closed_book) and (
        base_system in ("r_dense", "r_channel") or
        base_system.startswith("rrf"))
    if needs_dense:
        dense = DenseIndex(cfg.work_dir, name=_dense_name(cfg))
        if not dense.exists():
            if not args.auto_build_index:
                raise SystemExit(
                    f"\nERROR: dense index missing for encoder "
                    f"'{cfg.embed_model}'.\nEither rerun with "
                    f"--auto-build-index (builds it now, reusing the "
                    f"existing SQLite; ~30-60 min for a 137M encoder),\n"
                    f"or build it separately once:\n"
                    f"  python -m ccagef_bench.run_benchmark build-index "
                    f"--root {cfg.dataset_root} --work {cfg.work_dir} "
                    f"--embed-model {cfg.embed_model}")
            enc = make_encoder(cfg.embed_model, cfg.embed_fp16)
            print(f"--auto-build-index: building dense index for "
                  f"'{cfg.embed_model}' (SQLite reused; encoding "
                  f"{idx.count()} chunks) ...")
            t0 = time.time()
            dense.build(enc, idx.iter_texts(cfg.embed_max_chars),
                        batch_size=cfg.embed_batch_size,
                        total_hint=idx.count())
            dense.load()
            sample = [(eid, txt) for i, (eid, txt) in
                      enumerate(idx.iter_texts(cfg.embed_max_chars))
                      if i % max(1, idx.count() // 20) == 0][:20]
            hits = sum(1 for eid, txt in sample
                       if any(e == eid for e, _s in
                              dense.search(enc, txt, top_k=5)))
            rate = hits / max(len(sample), 1)
            print(f"dense index built in {time.time()-t0:.0f}s; "
                  f"self-retrieval {rate:.0%}")
            if rate < 0.6:
                dense.delete()
                raise SystemExit(
                    "ABORT: self-retrieval check failed — encoder is not "
                    "producing usable embeddings (index deleted). Check the "
                    "model id and trust_remote_code support.")
        else:
            dense.load()
        if enc is None:
            enc = make_encoder(cfg.embed_model, cfg.embed_fp16)

    # ---- 1. retrieval (reuse an existing run unless --force) --------------
    run = {}
    run_dir = Path(cfg.work_dir) / "runs" / cfg.split
    run_dir.mkdir(parents=True, exist_ok=True)
    run_path = run_dir / f"{run_name}.trec"
    if closed_book:
        print("closed-book method: retrieval skipped")
    elif run_path.exists() and not args.force:
        print(f"reusing existing run file: {run_path}")
        run = _read_trec_run(str(run_path))
    else:
        run = _retrieve_one_system(cfg, art, idx, dense, enc, base_system,
                                   qids, samples)
        _write_trec_run(run, str(run_path), run_name)
        print(f"wrote {run_path}")

    # ---- 2. retrieval metrics: strict + gold ONLY -------------------------
    out_dir = (Path(cfg.work_dir) / "results" / cfg.split / "method_runs" /
               args.method)
    out_dir.mkdir(parents=True, exist_ok=True)
    families = D.load_families(art.get("samples_internal"), qids)
    retrieval_summary = {}
    tier_plan = () if closed_book else (
        ("strict", "strict_qrels", STRICT_METRICS),
        ("gold", "gold_qrels", GOLD_METRICS))
    for tier, key, wanted in tier_plan:
        qrels = D.load_qrels(art[key])
        pq = P.evaluate_run_on_tier(run, qrels, tier, cfg, qids)
        summ = P.summarize(pq, families, cfg)
        retrieval_summary[tier] = {m: summ[m] for m in wanted if m in summ}
    with open(out_dir / "retrieval_metrics.json", "w") as fh:
        json.dump(retrieval_summary, fh, indent=1)

    # ---- 3. generation over this system's evidence ------------------------
    graph = frame_res = None
    if (not closed_book) and all(k in art for k in
                                 ("edges", "evidence_to_node")):
        graph = D.EvidenceGraph.load(art["edges"], art["evidence_to_node"])
        frame_res = D.load_frame_resolution(art["frame_resolution"]) \
            if "frame_resolution" in art else {}
    from .generation.harness import make_generator
    gen = make_generator(cfg.generator_model, cfg.generator_4bit,
                         cfg.generator_max_new_tokens)
    gen_path = out_dir / (f"gen_{run_name}.jsonl" if closed_book
                          else f"gen_rag_{run_name}.jsonl")
    with open(gen_path, "w") as fh:
        for n, qid in enumerate(qids, 1):
            if qid not in samples:
                continue
            if closed_book:
                prompt = build_prompt(samples[qid], [], [],
                                      closed_book=True)
            else:
                ranked = [d for d, _sc in run.get(qid, [])][:cfg.evidence_top_k]
                texts = idx.get_texts(ranked)
                ev = [texts[e] for e in ranked if e in texts]
                paths = R.top_graph_paths(qid, graph, frame_res, cfg) \
                    if graph else []
                prompt = build_prompt(samples[qid], ev, paths,
                                      char_budget=cfg.evidence_char_budget)
            rec = {"sample_id": qid, "output": parse_output(gen.generate(prompt))}
            fh.write(json.dumps(rec) + "\n")
            if n % 10 == 0:
                print(f"  generated {n}/{len(qids)}")
    print(f"generation outputs -> {gen_path}")

    # ---- 4. generation metrics (citations + content + abstention) ---------
    gold = D.load_qrels(art["gold_qrels"])
    strict = D.load_qrels(art["strict_qrels"])
    refs = {r["sample_id"]: r
            for r in D.iter_jsonl(str(art["references_gold"]))}
    corpus_ids = {i for i, _c in idx.all_ids_channels()}
    suffix_map = {}
    for cid in corpus_ids:
        suffix_map.setdefault(cid.split(":", 1)[1] if ":" in cid else cid,
                              cid)

    def _norm(c):
        c = c.strip().strip("[]").strip()
        return c if c in corpus_ids else suffix_map.get(c, c)

    from .generation.metrics import (citation_metrics, content_metrics,
                                     abstention_metrics)
    results = {r["sample_id"]: r["output"]
               for r in D.iter_jsonl(str(gen_path))}
    ungrounded = {q for q in qids
                  if not (strict.get(q) or gold.get(q))}
    pq = {}
    for qid, out in results.items():
        if out.get("abstain") or out.get("parse_error"):
            continue
        cm = citation_metrics([_norm(c) for c in out.get("citations", [])],
                              gold.get(qid, {}), corpus_ids,
                              cfg.gold_relevant_min_grade)
        cm.update(content_metrics(out, refs.get(qid)))
        for m, v in cm.items():
            pq.setdefault(m, {})[qid] = v
    gen_summary = {m: dict(zip(("mean", "ci_low", "ci_high", "n_families"),
                    mean_with_ci(vals, families, cfg.bootstrap_resamples,
                                 cfg.bootstrap_seed)))
                   for m, vals in pq.items()}
    ab = abstention_metrics(results, ungrounded)
    ab["n_ungrounded_in_split"] = len(ungrounded)
    with open(out_dir / "gen_metrics.json", "w") as fh:
        json.dump({"per_metric": gen_summary, "abstention": ab}, fh, indent=1)

    # ---- 5. final report + cross-method summary row -----------------------
    def _g(tier, m):
        v = retrieval_summary.get(tier, {}).get(m, {}).get("mean")
        return f"{v:.4f}" if isinstance(v, float) else "-"
    def _m(m):
        v = gen_summary.get(m, {}).get("mean")
        return f"{v:.4f}" if isinstance(v, float) else "-"
    print("\n" + "=" * 64)
    print(f"BENCHMARK COMPLETE - method={args.method}  system={run_name}")
    print(f"  retrieval  strict R@100={_g('strict','Recall@100')}  "
          f"RPrec={_g('strict','RPrec')}  nDCG@10={_g('strict','nDCG@10')}")
    print(f"             gold  nDCG@10={_g('gold','nDCG@10')}  "
          f"P@10={_g('gold','P@10')}  bpref={_g('gold','bpref')}  "
          f"Unjudged@10={_g('gold','Unjudged@10')}")
    print(f"  generation CitePrec={_m('CitePrecision')}  "
          f"HallucFabricated={_m('HallucFabricated')}  "
          f"HallucIrrelevant={_m('HallucIrrelevant')}")
    print(f"             CiteRecall={_m('CiteRecall')}  "
          f"SubsysMatch={_m('SubsysMatch')}  "
          f"CulpritHit={_m('CulpritHit')}  CulpritF1={_m('CulpritF1')}")
    print(f"  abstention AnswerRate={ab.get('AnswerRate')}  "
          f"ungrounded_in_split={ab['n_ungrounded_in_split']}")
    print("=" * 64)
    summ_path = (Path(cfg.work_dir) / "results" / cfg.split / "method_runs" /
                 "methods_summary.csv")
    header = ["method", "system", "strict_R@100", "strict_RPrec",
              "gold_nDCG@10", "gold_P@10", "gold_bpref", "gold_Unjudged@10",
              "CitePrecision", "HallucFabricated", "HallucIrrelevant",
              "CiteRecall", "SubsysMatch", "CulpritHit", "CulpritF1",
              "AnswerRate"]
    rows = {}
    if summ_path.exists():
        with open(summ_path, newline="") as fh:
            rows = {r["method"]: r for r in _csv.DictReader(fh)}
    rows[args.method] = dict(zip(header, [
        args.method, run_name,
        _g("strict", "Recall@100"), _g("strict", "RPrec"),
        _g("gold", "nDCG@10"), _g("gold", "P@10"), _g("gold", "bpref"),
        _g("gold", "Unjudged@10"),
        _m("CitePrecision"), _m("HallucFabricated"), _m("HallucIrrelevant"),
        _m("CiteRecall"), _m("SubsysMatch"), _m("CulpritHit"),
        _m("CulpritF1"),
        f"{ab.get('AnswerRate'):.4f}" if ab.get("AnswerRate") is not None
        else "-"]))
    with open(summ_path, "w", newline="") as fh:
        w = _csv.DictWriter(fh, fieldnames=header)
        w.writeheader()
        for k in sorted(rows):
            w.writerow(rows[k])
    print(f"cross-method summary updated -> {summ_path}")


SWEEP_PARAMS = {
    "beta":   ("graph_expand_bonus", ("expand", "ccagef")),
    "lambda": ("graph_rerank_weight", ("rerank", "ccagef")),
    "hops":   ("graph_hops", ("expand", "rerank", "ccagef")),
}


def stage_run_sweep(args) -> None:
    """Hyperparameter sensitivity sweep, retrieval-only, strict+gold.

    One row per value: retrieve the chosen system with the parameter
    overridden, evaluate, append to sweeps/sweep_<param>_<method>.csv.
    Defaults are NOT changed anywhere else; the pre-registered operating
    point stays the reported one. Run on --split validation for tuning
    claims; a test-split sweep is a post-hoc sensitivity analysis and must
    be described as such.
    """
    import csv as _csv
    if args.sweep_param not in SWEEP_PARAMS:
        raise SystemExit(f"--sweep-param must be one of {sorted(SWEEP_PARAMS)}")
    field, allowed = SWEEP_PARAMS[args.sweep_param]
    if args.method not in allowed:
        raise SystemExit(f"--method for this sweep must be one of {allowed}")
    values = [float(v) if args.sweep_param != "hops" else int(float(v))
              for v in args.sweep_values.split(",")]
    base_system, enc_key, _desc = METHODS[args.method]
    cfg = _load_cfg(args)
    if enc_key is not None:
        cfg.embed_model = ENCODERS[enc_key][0]
    art = discover_artifacts(cfg.dataset_root)
    require(art, ["samples_public", "strict_qrels", "gold_qrels"])
    qids = _split_ids(art, cfg)
    samples = D.load_samples(art["samples_public"], set(qids))
    idx = _open_index(cfg)
    dense = DenseIndex(cfg.work_dir, name=_dense_name(cfg))
    if not dense.exists():
        raise SystemExit("dense index missing; run build-index first")
    dense.load()
    enc = make_encoder(cfg.embed_model, cfg.embed_fp16)
    families = D.load_families(art.get("samples_internal"), qids)
    strict = D.load_qrels(art["strict_qrels"])
    gold = D.load_qrels(art["gold_qrels"])
    out_dir = Path(cfg.work_dir) / "results" / cfg.split / "sweeps"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_csv = out_dir / f"sweep_{args.sweep_param}_{args.method}.csv"
    header = ["param", "value", "system", "split", "strict_R@100",
              "strict_RPrec", "gold_nDCG@10", "gold_P@10", "gold_bpref"]
    rows = {}
    if out_csv.exists():
        with open(out_csv, newline="") as fh:
            rows = {r["value"]: r for r in _csv.DictReader(fh)}
    default_val = getattr(cfg, field)
    for v in values:
        setattr(cfg, field, v)
        print(f"--- sweep {args.sweep_param}={v} "
              f"(default {default_val}) system={base_system}")
        run = _retrieve_one_system(cfg, art, idx, dense, enc, base_system,
                                   qids, samples)
        rec = {"param": args.sweep_param, "value": v,
               "system": base_system, "split": cfg.split}
        for tier, qrels, wanted in (
                ("strict", strict, ("Recall@100", "RPrec")),
                ("gold", gold, ("nDCG@10", "P@10", "bpref"))):
            pq = P.evaluate_run_on_tier(run, qrels, tier, cfg, qids)
            summ = P.summarize(pq, families, cfg)
            for m in wanted:
                mv = summ.get(m, {}).get("mean")
                rec[f"{tier}_{m if m != 'Recall@100' else 'R@100'}"] = \
                    f"{mv:.4f}" if isinstance(mv, float) else "-"
        rows[str(v)] = rec
        with open(out_csv, "w", newline="") as fh:
            w = _csv.DictWriter(fh, fieldnames=header)
            w.writeheader()
            for k in sorted(rows, key=lambda x: float(x)):
                w.writerow(rows[k])
        print("   " + "  ".join(f"{k}={rec[k]}" for k in header[4:]))
    setattr(cfg, field, default_val)
    print(f"sweep table -> {out_csv}")


def stage_pool_sheet(args) -> None:
    """EVAL_PROTOCOL §4: annotator sheets for gold pool expansion.

    Union of every frozen system's top-N per test query, minus pairs already
    graded in gold, joined with evidence metadata and a text snippet. Output:
    one CSV per annotator batch + a manifest. Append the graded rows to
    gold_qrels.tsv and rerun `evaluate` — nothing else changes."""
    import csv as _csv
    cfg = _load_cfg(args)
    art = discover_artifacts(cfg.dataset_root)
    require(art, ["gold_qrels"])
    gold = D.load_qrels(art["gold_qrels"])
    idx = _open_index(cfg)
    run_dir = Path(cfg.work_dir) / "runs" / cfg.split
    run_files = sorted(run_dir.glob("*.trec"))
    if not run_files:
        raise SystemExit(f"no run files in {run_dir} — run `retrieve` first")
    depth = args.pool_depth
    # ---- auto-seeded near-certain candidates (marked, expert-confirmed) ----
    seeds: Dict[str, Dict[str, str]] = {}          # qid -> {eid: reason}
    if args.seed_fix_patches and "samples_internal" in art:
        # Seeds MUST be restricted to the split under expansion; otherwise
        # train/validation samples leak into the annotator sheets and inflate
        # the workload (protocol §4 expands the test pool only).
        split_qids = set(_split_ids(art, cfg))
        internal = D.load_samples(art["samples_internal"], split_qids)
        n_pat = n_lkml = 0
        for qid in internal:
            rec = internal[qid]
            fx = rec.get("fix_commit")
            if fx:
                cur = idx.conn.execute(
                    "SELECT evidence_id FROM evidence WHERE channel='patch' "
                    "AND evidence_id LIKE ?", (f"%:patch:{fx}%",)).fetchall()
                for (eid,) in cur:
                    seeds.setdefault(qid, {})[eid] = "auto:fix_patch"
                    n_pat += 1
            extid = (rec.get("provenance") or {}).get("extid")
            if extid and len(str(extid)) >= 8:
                cur = idx.conn.execute(
                    "SELECT e.evidence_id FROM evidence_fts "
                    "JOIN evidence e ON e.rowid=evidence_fts.rowid "
                    "WHERE evidence_fts MATCH ? AND e.channel='lkml' LIMIT 3",
                    (f'"{extid}"',)).fetchall()
                for (eid,) in cur:
                    seeds.setdefault(qid, {})[eid] = "auto:lkml_extid_match"
                    n_lkml += 1
        print(f"seeded candidates: {n_pat} fix-patch, {n_lkml} lkml-extid")
    pool: Dict[str, set] = {}
    split_qids = set(_split_ids(art, cfg))
    for p_ in run_files:
        run = _read_trec_run(str(p_))
        for qid, ranked in run.items():
            if qid in split_qids:
                pool.setdefault(qid, set()).update(d for d, _s in ranked[:depth])
    for qid, s_map in seeds.items():
        if qid in split_qids:
            pool.setdefault(qid, set()).update(s_map)
    rows = []
    for qid in sorted(pool):
        graded = set(gold.get(qid, {}))
        residual = sorted(pool[qid] - graded)
        s_map = seeds.get(qid, {})
        # seeded candidates first so annotators see them at the top
        residual.sort(key=lambda e: (e not in s_map, e))
        texts = idx.get_texts(residual)
        for eid in residual:
            m = texts.get(eid, {})
            rows.append([qid, eid, m.get("channel", ""), m.get("path", ""),
                         m.get("symbol", ""), (m.get("title") or "")[:120],
                         (m.get("text") or "")[:500].replace("\n", " "),
                         s_map.get(eid, ""), ""])
    out_dir = Path(cfg.work_dir) / "results" / cfg.split / "pool_expansion"
    out_dir.mkdir(parents=True, exist_ok=True)
    batch = max(1, args.batches)
    per = (len(rows) + batch - 1) // batch
    for b in range(batch):
        chunk = rows[b * per:(b + 1) * per]
        if not chunk:
            continue
        with open(out_dir / f"pool_sheet_batch{b+1:02d}.csv", "w",
                  newline="") as fh:
            w = _csv.writer(fh)
            w.writerow(["sample_id", "evidence_id", "channel", "path",
                        "symbol", "title", "text_snippet",
                        "seed_reason", "grade_0_to_3"])
            w.writerows(chunk)
    n_q = len(pool)
    print(f"pool expansion: {len(rows)} ungraded (query,doc) pairs over "
          f"{n_q} queries of split={cfg.split} (depth={depth}, "
          f"{len(run_files)} systems) -> {batch} sheet(s) in {out_dir}")
    print(f"avg new judgments per query: {len(rows)/max(n_q,1):.1f}")


def stage_sheet_to_qrels(args) -> None:
    """Step 4 of gold pool expansion: convert graded annotator sheets back
    into TREC qrels rows.

    Reads every pool_sheet_*.csv in the pool_expansion dir, validates grades,
    refuses rows that would overwrite an existing gold judgment, and writes
    gold_qrels_expansion.tsv (review it, then append to gold_qrels.tsv and
    bump the dataset version)."""
    import csv as _csv
    cfg = _load_cfg(args)
    art = discover_artifacts(cfg.dataset_root)
    require(art, ["gold_qrels"])
    gold = D.load_qrels(art["gold_qrels"])
    sheet_dir = Path(cfg.work_dir) / "results" / cfg.split / "pool_expansion"
    sheets = sorted(sheet_dir.glob("pool_sheet_*.csv"))
    if not sheets:
        raise SystemExit(f"no sheets found in {sheet_dir}")
    out_rows, skipped_blank, conflicts, invalid = [], 0, [], []
    seen: Dict[tuple, int] = {}
    for sh in sheets:
        with open(sh, newline="") as fh:
            for row in _csv.DictReader(fh):
                qid = (row.get("sample_id") or "").strip()
                eid = (row.get("evidence_id") or "").strip()
                g = (row.get("grade_0_to_3") or "").strip()
                if not qid or not eid:
                    continue
                if g == "":
                    skipped_blank += 1
                    continue
                if g not in ("0", "1", "2", "3"):
                    invalid.append((sh.name, qid, eid, g))
                    continue
                if eid in gold.get(qid, {}):
                    conflicts.append((qid, eid, gold[qid][eid], g))
                    continue
                key = (qid, eid)
                if key in seen and seen[key] != int(g):
                    invalid.append((sh.name, qid, eid,
                                    f"disagrees with earlier sheet ({seen[key]} vs {g})"))
                    continue
                if key not in seen:
                    seen[key] = int(g)
                    out_rows.append((qid, eid, g))
    out_path = sheet_dir / "gold_qrels_expansion.tsv"
    with open(out_path, "w") as fh:
        for qid, eid, g in sorted(out_rows):
            fh.write(f"{qid}\t0\t{eid}\t{g}\n")
    print(f"sheets read: {len(sheets)}")
    print(f"new qrels rows written: {len(out_rows)} -> {out_path}")
    print(f"ungraded rows skipped: {skipped_blank}")
    if conflicts:
        print(f"REFUSED {len(conflicts)} rows already graded in gold "
              f"(append-only policy), e.g. {conflicts[0]}")
    if invalid:
        print(f"INVALID {len(invalid)} rows (bad/conflicting grades), "
              f"e.g. {invalid[0]}")
    if out_rows:
        from collections import Counter
        ch = Counter(D.channel_of(e) for _q, e, _g in out_rows)
        gr = Counter(g for _q, _e, g in out_rows)
        print(f"new-row channels: {dict(ch)} | grades: {dict(gr)}")
        print("\nNext: review the file, then append and version-bump:")
        print(f"  cat {out_path} >> {art['gold_qrels']}")
        print("  (log as v1.2.1 in EVAL_PROTOCOL.md amendment table, "
              "then rerun `evaluate` and `gen-eval`)")


def stage_crash_cards(args) -> None:
    """Emit one plain-text crash card per sample so annotators can read the
    crash a sheet row refers to. Written next to the pool-expansion sheets:
    results/<split>/pool_expansion/crash_cards/<sample_id>.txt plus a single
    combined ALL_CRASHES.txt for ctrl-F lookup."""
    cfg = _load_cfg(args)
    art = discover_artifacts(cfg.dataset_root)
    require(art, ["samples_public"])
    qids = _split_ids(art, cfg)
    samples = D.load_samples(art["samples_public"], set(qids))
    out_dir = (Path(cfg.work_dir) / "results" / cfg.split /
               "pool_expansion" / "crash_cards")
    out_dir.mkdir(parents=True, exist_ok=True)
    combined = []
    for qid in qids:
        s_ = samples.get(qid)
        if not s_:
            continue
        pf = s_.get("parsed_features") or {}
        frames = [f.get("function") for f in (pf.get("frames") or [])
                  if f.get("function")]
        card = "\n".join([
            "=" * 72,
            f"SAMPLE:     {qid}",
            f"ERROR TYPE: {pf.get('error_type', '?')}   "
            f"SANITIZER: {pf.get('sanitizer', '?')}   "
            f"ARCH: {s_.get('architecture', '?')}",
            f"FUNCTIONS:  {', '.join(frames[:12]) or '?'}",
            f"FILES:      {', '.join((pf.get('files') or [])[:6]) or '?'}",
            "-" * 72,
            (s_.get("input", {}).get("normalized_log") or "")[:8000],
            ""])
        fn = qid.replace(":", "_").replace("/", "_") + ".txt"
        (out_dir / fn).write_text(card)
        combined.append(card)
    (out_dir / "ALL_CRASHES.txt").write_text("\n".join(combined))
    print(f"wrote {len(combined)} crash cards -> {out_dir}")
    print("annotators: open ALL_CRASHES.txt and Ctrl-F the sample_id from "
          "the sheet row")


def stage_diagnose_qrels(args) -> None:
    """Check that graded evidence ids exist in the index, per tier and
    channel; fuzzy-match missing ids by channel-stripped suffix to expose
    id-format drift (issue: docs ChRecall == 0 everywhere)."""
    cfg = _load_cfg(args)
    art = discover_artifacts(cfg.dataset_root)
    idx = _open_index(cfg)
    corpus = {i for i, _c in idx.all_ids_channels()}
    suffixes = {}
    for cid in corpus:
        suffixes.setdefault(cid.split(":", 1)[1] if ":" in cid else cid, cid)
    qids = set(_split_ids(art, cfg))
    from collections import Counter, defaultdict as dd
    for tier in ("strict_qrels", "silver_qrels", "gold_qrels"):
        if tier not in art:
            continue
        qrels = D.load_qrels(art[tier])
        tot, missing, fuzz = Counter(), Counter(), Counter()
        examples = dd(list)
        for qid, docs in qrels.items():
            if qid not in qids:
                continue
            for docid in docs:
                ch = D.channel_of(docid)
                tot[ch] += 1
                if docid not in corpus:
                    missing[ch] += 1
                    sfx = docid.split(":", 1)[1] if ":" in docid else docid
                    if sfx in suffixes:
                        fuzz[ch] += 1
                    if len(examples[ch]) < 3:
                        examples[ch].append(docid)
        print(f"\n=== {tier} (split={cfg.split}) ===")
        for ch in sorted(tot):
            print(f"  {ch:8s} graded={tot[ch]:>8,}  missing_in_index="
                  f"{missing[ch]:>8,} ({missing[ch]/tot[ch]:.1%})  "
                  f"recoverable_by_suffix={fuzz[ch]:,}")
            for ex in examples[ch]:
                print(f"      e.g. missing: {ex}")


def stage_all(args) -> None:
    stage_build_index(args)
    stage_retrieve(args)
    stage_evaluate(args)
    stage_localize(args)


# --------------------------------------------------------------------- main -

def main() -> None:
    ap = argparse.ArgumentParser(description="CC-AGEF benchmark")
    ap.add_argument("stage", choices=["discover", "build-index", "retrieve",
                                      "evaluate", "localize", "generate",
                                      "gen-eval", "pool-sheet", "sheet-to-qrels", "crash-cards", "run-method", "run-sweep",
                                      "diagnose-qrels", "all"])
    ap.add_argument("--root", required=True, help="dataset root directory")
    ap.add_argument("--work", default="./ccagef_work")
    ap.add_argument("--config", help="JSON file overriding BenchConfig fields")
    ap.add_argument("--split", default=None,
                    choices=["train", "validation", "test"])
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--embed-model", dest="embed_model", default=None)
    ap.add_argument("--generator-model", dest="generator_model", default=None)
    ap.add_argument("--run-name", default="rrf_graph_expand",
                    help="which run feeds the generator")
    ap.add_argument("--closed-book", action="store_true")
    ap.add_argument("--skip-dense", action="store_true")
    ap.add_argument("--skip-rerank", action="store_true")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--tag", default=None,
                    help="suffix for run files (e.g. embedder ablation)")
    ap.add_argument("--pool-depth", type=int, default=10)
    ap.add_argument("--batches", type=int, default=3,
                    help="number of annotator sheets for pool-sheet")
    ap.add_argument("--auto-build-index", action="store_true",
                    help="run-method: build a missing dense index inline "
                         "(reuses the existing SQLite)")
    ap.add_argument("--sweep-param", default=None,
                    help="run-sweep: beta | lambda | hops")
    ap.add_argument("--sweep-values", default=None,
                    help="run-sweep: comma-separated values, e.g. 0,0.2,0.35,0.5,1.0")
    ap.add_argument("--method", default=None,
                    help="run-method: one of " + ", ".join(sorted(METHODS)))
    ap.add_argument("--seed-fix-patches", action="store_true",
                    help="pool-sheet: add fix-commit patches + lkml extid "
                         "threads as marked auto-candidates")
    args = ap.parse_args()
    {"discover": stage_discover, "build-index": stage_build_index,
     "retrieve": stage_retrieve, "evaluate": stage_evaluate,
     "localize": stage_localize, "generate": stage_generate,
     "gen-eval": stage_gen_eval, "pool-sheet": stage_pool_sheet,
     "sheet-to-qrels": stage_sheet_to_qrels,
     "crash-cards": stage_crash_cards,
     "run-method": stage_run_method,
     "run-sweep": stage_run_sweep,
     "diagnose-qrels": stage_diagnose_qrels,
     "all": stage_all}[args.stage](args)


if __name__ == "__main__":
    main()
