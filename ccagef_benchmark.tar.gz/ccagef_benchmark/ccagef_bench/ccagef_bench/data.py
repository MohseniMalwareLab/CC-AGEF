"""Loaders for CC-AGEF dataset artifacts (streaming, memory-conscious)."""
from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, Iterator, List, Optional, Set, Tuple


def iter_jsonl(path: str) -> Iterator[dict]:
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if line:
                yield json.loads(line)


def load_jsonl(path: str) -> List[dict]:
    return list(iter_jsonl(path))


# ---------------------------------------------------------------- samples ---

def load_samples(path: str, ids: Optional[Set[str]] = None) -> Dict[str, dict]:
    out: Dict[str, dict] = {}
    for rec in iter_jsonl(path):
        sid = rec["sample_id"]
        if ids is None or sid in ids:
            out[sid] = rec
    return out


def load_split_ids(path: str) -> List[str]:
    with open(path) as fh:
        return [ln.strip() for ln in fh if ln.strip()]


def load_families(internal_path: Optional[str],
                  sample_ids: Iterable[str]) -> Dict[str, str]:
    """sample_id -> family key.

    Family = fix_commit group (statistical unit per EVAL_PROTOCOL §7). Falls
    back to event_group_id, then to the sample's own id, when the private
    internal file is unavailable.
    """
    fam: Dict[str, str] = {}
    if internal_path and Path(internal_path).exists():
        for rec in iter_jsonl(internal_path):
            key = rec.get("fix_commit") or rec.get("event_group_id") \
                or rec["sample_id"]
            fam[rec["sample_id"]] = f"fix:{key}"
    for sid in sample_ids:
        fam.setdefault(sid, f"self:{sid}")
    return fam


# ------------------------------------------------------------------ qrels ---

def load_qrels(path: str) -> Dict[str, Dict[str, int]]:
    """TREC qrels: qid \t iter \t docid \t grade."""
    qrels: Dict[str, Dict[str, int]] = defaultdict(dict)
    with open(path) as fh:
        for ln in fh:
            parts = ln.rstrip("\n").split("\t")
            if len(parts) < 4:
                parts = ln.split()
            if len(parts) < 4:
                continue
            qid, _it, docid, grade = parts[0], parts[1], parts[2], parts[3]
            qrels[qid][docid] = int(grade)
    return dict(qrels)


def qrels_relevant(qrels: Dict[str, Dict[str, int]], qid: str,
                   min_grade: int) -> Set[str]:
    return {d for d, g in qrels.get(qid, {}).items() if g >= min_grade}


# ------------------------------------------------------------- references ---

def load_references(path: str) -> Dict[str, dict]:
    return {r["sample_id"]: r for r in iter_jsonl(path)}


def load_eval_filters(path: str) -> Dict[str, dict]:
    return {r["sample_id"]: r for r in iter_jsonl(path)}


def load_frame_resolution(path: str) -> Dict[str, List[dict]]:
    return {r["sample_id"]: r.get("frames", []) for r in iter_jsonl(path)}


# ------------------------------------------------------------------ graph ---

class EvidenceGraph:
    """Typed evidence graph, sized for the full build (767k nodes, 2.96M
    edges stored bidirectionally ≈ 5.9M adjacency entries).

    Memory strategy: node ids are interned to ints; each adjacency entry is a
    single packed int ``(neighbor << 6) | rel_id`` (relation vocabulary is
    tiny), stored in ``array('q')`` per node. That keeps the whole graph in
    the low hundreds of MB instead of multiple GB of tuples — safe even on a
    standard-RAM Colab host.

    Hub handling: mega-degree nodes (``subsystem:*``, ``architecture:*`` and
    the like) are recorded but BFS never expands *through* a node whose
    degree exceeds ``hub_degree_cap`` — 2-hop expansion through
    ``subsystem:net`` would otherwise pull in tens of thousands of unrelated
    files. Hubs can still *be reached* (hop-1 neighbors), they just don't
    fan out.
    """

    REV_BIT = 1 << 5                       # marks reverse-direction edges

    def __init__(self, hub_degree_cap: int = 5000) -> None:
        self.id_of: Dict[str, int] = {}
        self.name_of: List[str] = []
        self.rel_of: Dict[str, int] = {}
        self.rel_name: List[str] = []
        self.adj: Dict[int, "array"] = {}
        self.node_evidence: Dict[int, List[str]] = {}
        self.hub_degree_cap = hub_degree_cap

    def _intern(self, node_id: str) -> int:
        i = self.id_of.get(node_id)
        if i is None:
            i = len(self.name_of)
            self.id_of[node_id] = i
            self.name_of.append(node_id)
        return i

    def _rel_id(self, rel: str) -> int:
        r = self.rel_of.get(rel)
        if r is None:
            r = len(self.rel_name)
            if r >= self.REV_BIT:
                raise ValueError("relation vocabulary exceeds packing width")
            self.rel_of[rel] = r
            self.rel_name.append(rel)
        return r

    def _append(self, u: int, v: int, rel_id: int, reverse: bool) -> None:
        from array import array
        lst = self.adj.get(u)
        if lst is None:
            lst = array("q")
            self.adj[u] = lst
        code = rel_id | (self.REV_BIT if reverse else 0)
        lst.append((v << 6) | code)

    @classmethod
    def load(cls, edges_path: str, evidence_to_node_path: str,
             nodes_path: Optional[str] = None,
             hub_degree_cap: int = 5000,
             log_every: int = 1_000_000) -> "EvidenceGraph":
        g = cls(hub_degree_cap=hub_degree_cap)
        n = 0
        for rec in iter_jsonl(edges_path):
            s = g._intern(rec["src"]); d = g._intern(rec["dst"])
            r = g._rel_id(rec.get("relation", "REL"))
            g._append(s, d, r, reverse=False)
            g._append(d, s, r, reverse=True)
            n += 1
            if n % log_every == 0:
                print(f"  graph edges loaded: {n:,}")
        for rec in iter_jsonl(evidence_to_node_path):
            i = g._intern(rec["node_id"])
            g.node_evidence.setdefault(i, []).append(rec["evidence_id"])
        return g

    def neighbors(self, node: int) -> List[Tuple[int, str]]:
        out: List[Tuple[int, str]] = []
        for packed in self.adj.get(node, ()):
            v, code = packed >> 6, packed & 0x3F
            rel = self.rel_name[code & (self.REV_BIT - 1)]
            out.append((v, ("~" + rel) if code & self.REV_BIT else rel))
        return out

    def degree(self, node: int) -> int:
        a = self.adj.get(node)
        return len(a) if a is not None else 0

    def expand(self, seed_ids: List[str], hops: int = 2,
               frontier_cap: int = 2000) -> Dict[str, int]:
        """BFS from seed node-id strings; returns node_id_str -> hop.
        Never expands through hub nodes (degree > hub_degree_cap)."""
        dist: Dict[int, int] = {}
        frontier: List[int] = []
        for s in seed_ids:
            i = self.id_of.get(s)
            if i is not None and i not in dist:
                dist[i] = 0
                frontier.append(i)
        for hop in range(1, hops + 1):
            nxt: List[int] = []
            for u in frontier:
                if hop > 1 and self.degree(u) > self.hub_degree_cap:
                    continue                       # reached, but no fan-out
                for packed in self.adj.get(u, ()):
                    v = packed >> 6
                    if v not in dist:
                        dist[v] = hop
                        nxt.append(v)
                        if len(nxt) >= frontier_cap:
                            break
                if len(nxt) >= frontier_cap:
                    break
            frontier = nxt
        return {self.name_of[i]: h for i, h in dist.items()}

    def evidence_at(self, node_id_str: str) -> List[str]:
        i = self.id_of.get(node_id_str)
        return self.node_evidence.get(i, []) if i is not None else []


# ------------------------------------------------------------ evidence id ---

def channel_of(evidence_id: str) -> str:
    return evidence_id.split(":", 1)[0] if ":" in evidence_id else "unknown"
