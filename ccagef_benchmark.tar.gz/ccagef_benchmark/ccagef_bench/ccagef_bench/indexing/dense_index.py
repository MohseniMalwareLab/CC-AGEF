"""Dense retrieval index.

Two encoder backends:
  * sentence-transformers model (default BAAI/bge-base-en-v1.5) — GPU, fp16.
  * "hash" — a deterministic hashed bag-of-tokens TF-IDF-style encoder that
    needs no download/GPU. Used for smoke tests and as a no-network fallback;
    it is NOT a substitute for a real embedder in reported results.

Vectors are L2-normalised float32 in a memmap on disk; search uses FAISS
IndexFlatIP when available, else a blocked numpy matmul (identical results).
730k x 768 float32 = ~2.2 GB — fine for Colab host RAM / GPU.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

_TOKEN_RE = re.compile(r"[A-Za-z0-9_]+")


class HashEncoder:
    dim = 1024

    def encode(self, texts: Sequence[str], **_kw) -> np.ndarray:
        out = np.zeros((len(texts), self.dim), dtype=np.float32)
        for i, t in enumerate(texts):
            toks = _TOKEN_RE.findall(t.lower())
            for tok in toks:
                h = int(hashlib.blake2b(tok.encode(), digest_size=8)
                        .hexdigest(), 16)
                idx = h % self.dim
                sign = 1.0 if (h >> 63) & 1 else -1.0
                # dampened tf, idf-ish penalty for very short tokens
                out[i, idx] += sign * (1.0 + math.log(1 + toks.count(tok))) \
                    * (0.3 if len(tok) <= 2 else 1.0)
            n = np.linalg.norm(out[i])
            if n > 0:
                out[i] /= n
        return out


# Instruction-tuned retrievers that REQUIRE a query-side task prefix.
# Passages are embedded bare; only queries get the prefix (enforced in
# DenseIndex.search, the single query-encode path). Missing prefixes fail
# silently with near-random retrieval -- the post-build self-check is the
# net that catches any future model added without its prefix.
QUERY_PREFIXES = {
    "nomic-ai/CodeRankEmbed":
        "Represent this query for searching relevant code: ",
    "cornstack/CodeRankEmbed":
        "Represent this query for searching relevant code: ",
    "Salesforce/SweRankEmbed-Small":
        "Represent this query for searching relevant code: ",
    "Salesforce/SweRankEmbed-Large":
        "Represent this query for searching relevant code: ",
}


def make_encoder(model_name: str, fp16: bool = True):
    if model_name == "hash":
        enc = HashEncoder()
        enc.query_prefix = QUERY_PREFIXES.get(model_name, "")
        return enc
    from sentence_transformers import SentenceTransformer  # lazy import
    import torch
    device = "cuda" if torch.cuda.is_available() else "cpu"
    # Layered loading: custom architectures (e.g. jina-embeddings-v2-*)
    # need trust_remote_code; some ship legacy attn_implementation values
    # ("torch") that current transformers rejects, so we override at the
    # config level, falling back through progressively safer settings.
    attempts = [
        {"trust_remote_code": True},
        {"trust_remote_code": True,
         "config_kwargs": {"attn_implementation": "sdpa"}},
        {"trust_remote_code": True,
         "config_kwargs": {"attn_implementation": "eager"}},
        {"config_kwargs": {"attn_implementation": "eager"}},
        {},
    ]
    last_err = None
    for i, kw in enumerate(attempts, 1):
        try:
            model = SentenceTransformer(model_name, device=device, **kw)
            if i > 1:
                print(f"encoder loaded with fallback strategy {i}: {kw}")
            break
        except Exception as e:                      # noqa: BLE001
            last_err = e
    else:
        raise RuntimeError(
            f"could not load embedder '{model_name}' after "
            f"{len(attempts)} strategies; last error: {last_err}")
    if fp16 and device == "cuda":
        try:
            model = model.half()
        except Exception:
            print("fp16 unsupported for this encoder — using fp32")
    model.query_prefix = QUERY_PREFIXES.get(model_name, "")
    if model.query_prefix:
        print(f"query prefix active for {model_name!r}")
    return model


class DenseIndex:
    def __init__(self, work_dir: str, name: str = "dense") -> None:
        self.dir = Path(work_dir); self.dir.mkdir(parents=True, exist_ok=True)
        self.name = name
        self.ids: List[str] = []
        self.mat: Optional[np.ndarray] = None
        self._faiss = None

    @property
    def _vec_path(self) -> Path:
        return self.dir / f"{self.name}_vectors.npy"

    @property
    def _ids_path(self) -> Path:
        return self.dir / f"{self.name}_ids.json"

    def exists(self) -> bool:
        return self._vec_path.exists() and self._ids_path.exists()

    # ---------------------------------------------------------------- build
    def build(self, encoder, texts_iter: Iterable[Tuple[str, str]],
              batch_size: int = 128, total_hint: Optional[int] = None) -> None:
        ids: List[str] = []
        blocks: List[np.ndarray] = []
        batch_ids: List[str] = []; batch_txt: List[str] = []
        done = 0
        for eid, text in texts_iter:
            batch_ids.append(eid); batch_txt.append(text)
            if len(batch_txt) >= batch_size:
                vecs = np.asarray(encoder.encode(
                    batch_txt, batch_size=batch_size,
                    show_progress_bar=False,
                    normalize_embeddings=True), dtype=np.float32)
                blocks.append(vecs); ids.extend(batch_ids)
                done += len(batch_ids)
                if total_hint and done % (batch_size * 50) < batch_size:
                    print(f"  embedded {done:,}/{total_hint:,}")
                batch_ids, batch_txt = [], []
        if batch_txt:
            vecs = np.asarray(encoder.encode(
                batch_txt, batch_size=batch_size, show_progress_bar=False,
                normalize_embeddings=True), dtype=np.float32)
            blocks.append(vecs); ids.extend(batch_ids)
        mat = np.vstack(blocks) if blocks else np.zeros((0, 1), np.float32)
        # normalise defensively (hash encoder + any model without the flag)
        norms = np.linalg.norm(mat, axis=1, keepdims=True); norms[norms == 0] = 1
        mat = mat / norms
        np.save(self._vec_path, mat)
        self._ids_path.write_text(json.dumps(ids))
        self.ids, self.mat = ids, mat
        print(f"dense index built: {mat.shape[0]:,} x {mat.shape[1]} "
              f"-> {self._vec_path}")

    # ----------------------------------------------------------------- load
    def load(self, use_faiss: bool = True) -> None:
        self.mat = np.load(self._vec_path, mmap_mode="r")
        self.ids = json.loads(self._ids_path.read_text())
        if use_faiss:
            try:
                import faiss
                idx = faiss.IndexFlatIP(self.mat.shape[1])
                idx.add(np.ascontiguousarray(self.mat, dtype=np.float32))
                self._faiss = idx
            except Exception:
                self._faiss = None

    # --------------------------------------------------------------- search
    def search(self, encoder, query: str, top_k: int = 100
               ) -> List[Tuple[str, float]]:
        query = getattr(encoder, "query_prefix", "") + query
        q = np.asarray(encoder.encode([query], normalize_embeddings=True),
                       dtype=np.float32)
        n = np.linalg.norm(q, axis=1, keepdims=True); n[n == 0] = 1
        q = q / n
        if self._faiss is not None:
            scores, idxs = self._faiss.search(q, top_k)
            return [(self.ids[i], float(s))
                    for i, s in zip(idxs[0], scores[0]) if i >= 0]
        # blocked matmul fallback
        assert self.mat is not None
        best_scores = np.full(top_k, -1e9, np.float32)
        best_idx = np.full(top_k, -1, np.int64)
        B = 200_000
        for start in range(0, self.mat.shape[0], B):
            block = np.asarray(self.mat[start:start + B], dtype=np.float32)
            sims = block @ q[0]
            k = min(top_k, sims.shape[0])
            part = np.argpartition(-sims, k - 1)[:k]
            cand_s = np.concatenate([best_scores, sims[part]])
            cand_i = np.concatenate([best_idx, part + start])
            order = np.argsort(-cand_s)[:top_k]
            best_scores, best_idx = cand_s[order], cand_i[order]
        return [(self.ids[i], float(s))
                for i, s in zip(best_idx, best_scores) if i >= 0]
