"""SQLite-backed evidence store, FTS5 BM25 index, and symbol lookup table.

Everything streams from corpus/evidence.jsonl, so host RAM stays flat even
for the 730k-chunk corpus. The database lives in the work dir (or, better on
Colab, on the local VM disk rather than Drive, for I/O speed).
"""
from __future__ import annotations

import json
import re
import sqlite3
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

from ..data import iter_jsonl

_TOKEN_RE = re.compile(r"[A-Za-z0-9_./]+")


def _fts_query(text: str, max_terms: int = 32) -> str:
    """Escape free text into a safe FTS5 OR-query of quoted terms."""
    terms = _TOKEN_RE.findall(text)[:max_terms]
    if not terms:
        return '""'
    return " OR ".join('"%s"' % t.replace('"', "") for t in terms)


class SqliteEvidenceIndex:
    def __init__(self, db_path: str) -> None:
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        try:
            # WAL needs shared-memory files; FUSE mounts (Google Drive)
            # don't support them reliably — fall back to rollback journal.
            if "/drive/" in str(db_path):
                self.conn.execute("PRAGMA journal_mode=DELETE")
            else:
                self.conn.execute("PRAGMA journal_mode=WAL")
        except sqlite3.OperationalError:
            self.conn.execute("PRAGMA journal_mode=DELETE")
        self.conn.execute("PRAGMA synchronous=OFF")

    def is_built(self) -> bool:
        """True iff the evidence table exists and is non-empty."""
        try:
            row = self.conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' "
                "AND name='evidence'").fetchone()
            if not row:
                return False
            return self.conn.execute(
                "SELECT EXISTS(SELECT 1 FROM evidence)").fetchone()[0] == 1
        except sqlite3.OperationalError:
            return False

    # -------------------------------------------------------------- build --
    def build(self, evidence_path: str,
              symbol_index_path: Optional[str] = None,
              log_every: int = 100_000) -> None:
        c = self.conn
        c.executescript("""
        DROP TABLE IF EXISTS evidence;
        DROP TABLE IF EXISTS evidence_functions;
        DROP TABLE IF EXISTS evidence_fts;
        CREATE TABLE evidence(
            rowid INTEGER PRIMARY KEY,
            evidence_id TEXT UNIQUE, channel TEXT, title TEXT, path TEXT,
            symbol TEXT, symbol_kind TEXT, subsystem TEXT,
            entity_node_id TEXT, text TEXT);
        CREATE TABLE evidence_functions(
            symbol TEXT, evidence_id TEXT, path TEXT, symbol_kind TEXT,
            subsystem TEXT);
        CREATE VIRTUAL TABLE evidence_fts USING fts5(
            title, path, symbol, text,
            content='evidence', content_rowid='rowid',
            tokenize="unicode61 tokenchars '_./'");
        """)
        n = 0
        batch: List[Tuple] = []
        for rec in iter_jsonl(evidence_path):
            batch.append((
                rec["evidence_id"], rec.get("channel", "unknown"),
                rec.get("title") or "", rec.get("path") or "",
                rec.get("symbol") or "", rec.get("symbol_kind") or "",
                rec.get("subsystem") or "", rec.get("entity_node_id") or "",
                (rec.get("text") or "")[:32_000]))
            if len(batch) >= 2000:
                c.executemany(
                    "INSERT OR IGNORE INTO evidence(evidence_id,channel,title,"
                    "path,symbol,symbol_kind,subsystem,entity_node_id,text) "
                    "VALUES(?,?,?,?,?,?,?,?,?)", batch)
                n += len(batch); batch.clear()
                if n % log_every < 2000:
                    print(f"  evidence rows: {n:,}")
        if batch:
            c.executemany(
                "INSERT OR IGNORE INTO evidence(evidence_id,channel,title,path,"
                "symbol,symbol_kind,subsystem,entity_node_id,text) "
                "VALUES(?,?,?,?,?,?,?,?,?)", batch)
            n += len(batch)
        c.execute("INSERT INTO evidence_fts(rowid,title,path,symbol,text) "
                  "SELECT rowid,title,path,symbol,text FROM evidence")
        # symbol table: prefer the shipped code_symbol_index, else derive
        if symbol_index_path and Path(symbol_index_path).exists():
            rows = [(r["symbol"], r["evidence_id"], r.get("path") or "",
                     r.get("symbol_kind") or "", r.get("subsystem") or "")
                    for r in iter_jsonl(symbol_index_path)]
            c.executemany("INSERT INTO evidence_functions VALUES(?,?,?,?,?)",
                          rows)
        else:
            c.execute("INSERT INTO evidence_functions "
                      "SELECT symbol, evidence_id, path, symbol_kind, subsystem "
                      "FROM evidence WHERE symbol != ''")
        c.executescript("""
        CREATE INDEX IF NOT EXISTS idx_ef_symbol ON evidence_functions(symbol);
        CREATE INDEX IF NOT EXISTS idx_ev_channel ON evidence(channel);
        CREATE INDEX IF NOT EXISTS idx_ev_eid ON evidence(evidence_id);
        """)
        c.commit()
        print(f"index built: {n:,} evidence rows -> {self.db_path}")

    # ------------------------------------------------------------- lookup --
    def symbol_lookup(self, symbol: str, limit: int = 50) -> List[dict]:
        cur = self.conn.execute(
            "SELECT symbol, evidence_id, path, symbol_kind, subsystem "
            "FROM evidence_functions WHERE symbol = ? LIMIT ?", (symbol, limit))
        return [dict(zip(("symbol", "evidence_id", "path", "symbol_kind",
                          "subsystem"), r)) for r in cur.fetchall()]

    def bm25(self, query_text: str, top_k: int = 100,
             channel: Optional[str] = None) -> List[Tuple[str, float]]:
        q = _fts_query(query_text)
        if channel:
            sql = ("SELECT e.evidence_id, bm25(evidence_fts) AS s "
                   "FROM evidence_fts JOIN evidence e ON e.rowid=evidence_fts.rowid "
                   "WHERE evidence_fts MATCH ? AND e.channel = ? "
                   "ORDER BY s LIMIT ?")
            cur = self.conn.execute(sql, (q, channel, top_k))
        else:
            sql = ("SELECT e.evidence_id, bm25(evidence_fts) AS s "
                   "FROM evidence_fts JOIN evidence e ON e.rowid=evidence_fts.rowid "
                   "WHERE evidence_fts MATCH ? ORDER BY s LIMIT ?")
            cur = self.conn.execute(sql, (q, top_k))
        # bm25() returns lower=better; negate so higher=better everywhere.
        return [(eid, -score) for eid, score in cur.fetchall()]

    def get_texts(self, evidence_ids: List[str]) -> Dict[str, dict]:
        out: Dict[str, dict] = {}
        for i in range(0, len(evidence_ids), 500):
            chunk = evidence_ids[i:i + 500]
            marks = ",".join("?" * len(chunk))
            cur = self.conn.execute(
                f"SELECT evidence_id, channel, title, path, symbol, subsystem, "
                f"text FROM evidence WHERE evidence_id IN ({marks})", chunk)
            for r in cur.fetchall():
                out[r[0]] = dict(zip(("evidence_id", "channel", "title", "path",
                                      "symbol", "subsystem", "text"), r))
        return out

    def all_ids_channels(self) -> List[Tuple[str, str]]:
        cur = self.conn.execute("SELECT evidence_id, channel FROM evidence "
                                "ORDER BY rowid")
        return cur.fetchall()

    def iter_texts(self, max_chars: int = 2000
                   ) -> Iterable[Tuple[str, str]]:
        cur = self.conn.execute(
            "SELECT evidence_id, substr(title||' '||path||' '||symbol||' '"
            "||text, 1, ?) FROM evidence ORDER BY rowid", (max_chars,))
        while True:
            rows = cur.fetchmany(2000)
            if not rows:
                break
            for r in rows:
                yield r[0], r[1] or ""

    def count(self) -> int:
        return self.conn.execute("SELECT COUNT(*) FROM evidence").fetchone()[0]
