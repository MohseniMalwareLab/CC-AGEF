from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional

# Canonical artifact names -> list of accepted filename patterns (first match
# wins; searched case-insensitively by basename).
ARTIFACT_PATTERNS: Dict[str, List[str]] = {
    "samples_public": ["samples_public.jsonl", "samples_public.json",
                       "samples_public_10.json"],
    "samples_internal": ["samples_full_internal.jsonl",
                         "samples_full_internal.json",
                         "samples_full_internal_10.json"],
    "references_silver": ["references_private.jsonl", "references_private.json",
                          "references_private_10.json"],
    "references_gold": ["references_expert_gold.jsonl",
                        "references_expert_gold.json",
                        "references_expert_gold_10.json"],
    "evidence": ["evidence.jsonl", "evidence.json", "evidence_10.json"],
    "code_symbol_index": ["code_symbol_index.jsonl", "code_symbol_index.json",
                          "code_symbol_index_10.json"],
    "nodes": ["nodes.jsonl", "node.jsonl", "node_10.jsonl"],
    "edges": ["edges.jsonl", "edges_10.jsonl"],
    "evidence_to_node": ["evidence_to_node.jsonl", "evidence_to_node_10.jsonl"],
    "frame_resolution": ["sample_frame_resolution.jsonl",
                         "sample_frame_resolution_10.jsonl"],
    "strict_qrels": ["strict_qrels.tsv", "strict_qrels_10.tsv"],
    "silver_qrels": ["silver_qrels.tsv", "silver_qrels_10.tsv"],
    "gold_qrels": ["gold_qrels.tsv", "gold_qrels_tsv.tsv",
                   "gold_qrels_tsv_10.tsv"],
    "train_ids": ["train_ids.txt", "train_ids_10.txt"],
    "validation_ids": ["validation_ids.txt", "validation_ids_10.txt"],
    "test_ids": ["test_ids.txt", "test_ids_10.txt"],
    "split_manifest": ["split_manifest.json", "split_manifest_10.json"],
    "eval_filters": ["retrieval_eval_filters.jsonl",
                     "retrieval_eval_filters_10.jsonl"],
}

# Generic sanitizer / infrastructure frames that carry no localization signal.
GENERIC_FRAMES = {
    "dump_stack", "__dump_stack", "dump_stack_lvl", "kmsan_report",
    "kasan_report", "__msan_warning", "__msan_warning_with_origin",
    "__kasan_report", "print_report", "check_memory_region", "panic",
    "__warn", "warn_slowpath_fmt", "report_bug", "process_one_work",
    "worker_thread", "kthread", "ret_from_fork", "ret_from_fork_asm",
    "do_syscall_64", "entry_SYSCALL_64_after_hwframe", "__x64_sys_ioctl",
    "__do_sys_ioctl", "do_softirq", "__do_softirq", "call_timer_fn",
    "run_timer_softirq", "__run_timers", "asm_common_interrupt",
    "common_interrupt", "handle_irq_event", "__handle_irq_event_percpu",
    "kasan_check_range", "__asan_load8", "__asan_store8", "__asan_load4",
    "instrument_atomic_read", "lock_acquire", "lock_release", "__lock_acquire",
    "debug_check_no_locks_held", "rcu_read_lock", "rcu_read_unlock",
    "memcpy", "memset",  # near-universal helpers: keep memcmp (often culprit-adjacent)
}

# Path prefixes that are implausible resolutions for an x86_64 kernel crash.
IMPLAUSIBLE_PATH_PREFIXES = (
    "tools/", "scripts/", "samples/", "Documentation/",
    "arch/arm", "arch/arm64", "arch/s390", "arch/powerpc", "arch/mips",
    "arch/riscv", "arch/sparc", "arch/parisc", "arch/alpha", "arch/m68k",
    "arch/xtensa", "arch/sh", "arch/um", "arch/loongarch", "arch/openrisc",
    "arch/nios2", "arch/microblaze", "arch/hexagon", "arch/csky", "arch/arc",
)


@dataclass
class BenchConfig:
    dataset_root: str
    work_dir: str = "./ccagef_work"
    # --- indexing ---
    embed_model: str = "BAAI/bge-base-en-v1.5"   # "hash" => offline fallback
    # code-centric ablation partner: jinaai/jina-code-embeddings-0.5b
    # (standard architecture; v2-base-code needs remote code and can
    #  silently load broken without it - the build self-check catches this)
    embed_batch_size: int = 128
    embed_max_chars: int = 2000                    # truncate chunk text before embedding
    embed_fp16: bool = True
    faiss_index: str = "flat"                      # flat | ivf
    # --- retrieval ---
    top_k_retrieve: int = 100                      # depth of each base run
    channel_quotas: Dict[str, int] = field(default_factory=lambda: {
        "code": 60, "patch": 15, "cve": 10, "docs": 10, "lkml": 5})
    rrf_k: int = 60
    max_stack_functions: int = 12
    filter_generic_frames: bool = True
    filter_implausible_paths: bool = True
    # --- graph ---
    graph_hops: int = 2
    graph_neighbor_cap: int = 2000                 # per-seed frontier cap
    graph_expand_bonus: float = 0.35               # score for hop-1 evidence
    graph_decay: float = 0.5                       # per-hop decay
    graph_rerank_weight: float = 0.4
    # --- rerank ---
    reranker_model: str = "BAAI/bge-reranker-v2-m3"  # amendment 2026-07-12: ms-marco (web passages) unsuited to kernel code
    rerank_depth: int = 50
    # --- evaluation (mirrors EVAL_PROTOCOL.md; do not change mid-study) ---
    strict_min_grade: int = 2
    silver_min_grade: int = 1   # amendment 2026-07-11: differentiates silver from strict
    gold_relevant_min_grade: int = 1
    recall_ks: List[int] = field(default_factory=lambda: [5, 10, 20, 100])
    precision_ks: List[int] = field(default_factory=lambda: [5, 10])
    ndcg_k: int = 10
    unjudged_k: int = 10
    bootstrap_resamples: int = 1000
    bootstrap_seed: int = 7
    # --- generation ---
    generator_model: str = "Qwen/Qwen2.5-Coder-7B-Instruct"
    generator_4bit: bool = True
    generator_max_new_tokens: int = 512
    evidence_top_k: int = 10
    evidence_char_budget: int = 24000
    # --- misc ---
    split: str = "test"
    limit: Optional[int] = None                    # cap #queries (smoke tests)

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2)


def discover_artifacts(root: str) -> Dict[str, str]:
    """Walk `root` and map canonical artifact names to concrete paths."""
    root_p = Path(root)
    if not root_p.exists():
        raise FileNotFoundError(f"dataset root not found: {root}")
    by_name: Dict[str, str] = {}
    for dirpath, _dirnames, filenames in os.walk(root_p):
        for fn in filenames:
            by_name.setdefault(fn.lower(), str(Path(dirpath) / fn))
    found: Dict[str, str] = {}
    for key, patterns in ARTIFACT_PATTERNS.items():
        for pat in patterns:
            if pat.lower() in by_name:
                found[key] = by_name[pat.lower()]
                break
    return found


def require(artifacts: Dict[str, str], keys: List[str]) -> None:
    missing = [k for k in keys if k not in artifacts]
    if missing:
        raise FileNotFoundError(
            "missing required dataset artifacts: %s (searched patterns: %s)"
            % (missing, {k: ARTIFACT_PATTERNS[k] for k in missing}))
