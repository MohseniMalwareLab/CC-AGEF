"""Base retrievers (R_symbol, R_bm25, R_dense, R_channel), RRF fusion, and
graph fusion (expansion + proximity rerank).

All retrievers return List[(evidence_id, score)] sorted descending; the run
format everywhere is TREC-style {qid: [(docid, score), ...]}.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Dict, List, Optional, Sequence, Set, Tuple

from ..config import BenchConfig, GENERIC_FRAMES, IMPLAUSIBLE_PATH_PREFIXES
from ..data import EvidenceGraph, channel_of
from ..indexing.sqlite_index import SqliteEvidenceIndex

Run = List[Tuple[str, float]]


def _stack_functions(sample: dict, cfg: BenchConfig) -> List[str]:
    frames = (sample.get("parsed_features") or {}).get("frames") or []
    fns = [f.get("function") for f in frames if f.get("function")]
    if not fns:
        fns = (sample.get("input", {}).get("query_views", {})
               .get("symbol_query", "").split())
    if cfg.filter_generic_frames:
        fns = [f for f in fns if f not in GENERIC_FRAMES]
    return fns[:cfg.max_stack_functions]


def _plausible(path: str, cfg: BenchConfig) -> bool:
    if not cfg.filter_implausible_paths or not path:
        return True
    return not path.startswith(IMPLAUSIBLE_PATH_PREFIXES)


# ---------------------------------------------------------------- R_symbol --

def r_symbol(sample: dict, idx: SqliteEvidenceIndex,
             cfg: BenchConfig) -> Run:
    scores: Dict[str, float] = {}
    fns = _stack_functions(sample, cfg)
    crash_files = set((sample.get("parsed_features") or {}).get("files") or [])
    for pos, fn in enumerate(fns):
        base = 1.0 / (1.0 + pos)                     # top frames first
        for row in idx.symbol_lookup(fn, limit=50):
            eid, path = row["evidence_id"], row.get("path") or ""
            s = base
            if row.get("symbol_kind") == "function":
                s *= 1.5                              # definition > caller
            if path in crash_files:
                s *= 2.0                              # path corroborated by log
            elif not _plausible(path, cfg):
                s *= 0.2                              # wrong-arch / tools copy
            if s > scores.get(eid, 0.0):
                scores[eid] = s
    ranked = sorted(scores.items(), key=lambda x: -x[1])
    return ranked[:cfg.top_k_retrieve]


# ------------------------------------------------------------------ R_bm25 --

def r_bm25(sample: dict, idx: SqliteEvidenceIndex, cfg: BenchConfig) -> Run:
    q = (sample.get("input", {}).get("query_views", {})
         .get("keyword_query", ""))
    return idx.bm25(q, top_k=cfg.top_k_retrieve)


# ----------------------------------------------------------------- R_dense --

def r_dense(sample: dict, dense, encoder, cfg: BenchConfig) -> Run:
    q = (sample.get("input", {}).get("query_views", {})
         .get("dense_query", ""))[:4000]
    return dense.search(encoder, q, top_k=cfg.top_k_retrieve)


# --------------------------------------------------------------- R_channel --

def r_channel(sample: dict, idx: SqliteEvidenceIndex, dense, encoder,
              cfg: BenchConfig) -> Run:
    """Per-channel quotas so non-code evidence is guaranteed representation.

    Lexical (BM25-per-channel) and dense results are themselves RRF-merged
    inside each channel, then channels are concatenated by quota with scores
    offset so ordering is code-first but stable.
    """
    kw = sample.get("input", {}).get("query_views", {}).get("keyword_query", "")
    dq = sample.get("input", {}).get("query_views", {}).get("dense_query", "")[:4000]
    dense_hits = dense.search(encoder, dq, top_k=cfg.top_k_retrieve * 2) \
        if dense is not None else []
    dense_by_ch: Dict[str, Run] = defaultdict(list)
    for eid, s in dense_hits:
        dense_by_ch[channel_of(eid)].append((eid, s))
    out: Run = []
    for ch, quota in cfg.channel_quotas.items():
        lex = idx.bm25(kw, top_k=quota * 3, channel=ch)
        merged = rrf([lex, dense_by_ch.get(ch, [])], k=cfg.rrf_k)[:quota]
        # keep RRF score; channel identity preserved through the id itself
        out.extend(merged)
    return sorted(out, key=lambda x: -x[1])[:cfg.top_k_retrieve]


# --------------------------------------------------------------------- RRF --

def rrf(runs: Sequence[Run], k: int = 60) -> Run:
    scores: Dict[str, float] = defaultdict(float)
    for run in runs:
        for rank, (eid, _s) in enumerate(run):
            scores[eid] += 1.0 / (k + rank + 1)
    return sorted(scores.items(), key=lambda x: -x[1])


def weighted_fusion(runs: Sequence[Run], weights: Sequence[float]) -> Run:
    """Min-max normalised weighted score fusion (ablation baseline)."""
    scores: Dict[str, float] = defaultdict(float)
    for run, w in zip(runs, weights):
        if not run:
            continue
        vals = [s for _e, s in run]
        lo, hi = min(vals), max(vals)
        rng = (hi - lo) or 1.0
        for eid, s in run:
            scores[eid] += w * (s - lo) / rng
    return sorted(scores.items(), key=lambda x: -x[1])


# ------------------------------------------------------------ graph fusion --

def graph_seeds(sample_id: str, frame_res: Dict[str, List[dict]],
                cfg: BenchConfig) -> List[str]:
    seeds: List[str] = []
    for fr in frame_res.get(sample_id, []):
        fn, node = fr.get("function"), fr.get("node_id")
        if not node:
            continue
        if cfg.filter_generic_frames and fn in GENERIC_FRAMES:
            continue
        # node ids look like function:<commit>:<path>:<symbol>
        parts = node.split(":")
        path = parts[2] if len(parts) >= 3 else ""
        if not _plausible(path, cfg):
            continue
        seeds.append(node)
    return seeds


def graph_expand_run(base: Run, sample_id: str, graph: EvidenceGraph,
                     frame_res: Dict[str, List[dict]],
                     cfg: BenchConfig) -> Run:
    """Fusion strategy (2): add graph-neighbor evidence to the pool."""
    seeds = graph_seeds(sample_id, frame_res, cfg)
    dist = graph.expand(seeds, hops=cfg.graph_hops,
                        frontier_cap=cfg.graph_neighbor_cap)
    scores: Dict[str, float] = dict(base)
    top = scores and max(scores.values()) or 1.0
    for node_id, hop in dist.items():
        bonus = top * cfg.graph_expand_bonus * (cfg.graph_decay ** max(hop - 1, 0))
        for eid in graph.evidence_at(node_id):
            scores[eid] = max(scores.get(eid, 0.0), 0.0) + bonus
    return sorted(scores.items(), key=lambda x: -x[1])[:cfg.top_k_retrieve]


def graph_rerank_run(base: Run, sample_id: str, graph: EvidenceGraph,
                     frame_res: Dict[str, List[dict]],
                     evidence_nodes: Dict[str, str],
                     cfg: BenchConfig) -> Run:
    """Fusion strategy (3): boost pool items by graph proximity to the seeds.

    evidence_nodes: evidence_id -> entity_node_id (from the sqlite store).
    """
    seeds = graph_seeds(sample_id, frame_res, cfg)
    dist = graph.expand(seeds, hops=cfg.graph_hops,
                        frontier_cap=cfg.graph_neighbor_cap)
    if not base:
        return base
    vals = [s for _e, s in base]
    lo, hi = min(vals), max(vals); rng = (hi - lo) or 1.0
    out: Run = []
    for eid, s in base:
        prox = 0.0
        node = evidence_nodes.get(eid)
        if node is not None and node in dist:
            prox = 1.0 / (1.0 + dist[node])
        out.append((eid, (s - lo) / rng + cfg.graph_rerank_weight * prox))
    return sorted(out, key=lambda x: -x[1])


def top_graph_paths(sample_id: str, graph: EvidenceGraph,
                    frame_res: Dict[str, List[dict]], cfg: BenchConfig,
                    max_paths: int = 5) -> List[str]:
    """Fusion strategy (4) helper: human-readable seed->neighbor paths for
    injection into the generator prompt."""
    paths: List[str] = []
    for seed in graph_seeds(sample_id, frame_res, cfg)[:max_paths]:
        i = graph.id_of.get(seed)
        if i is None:
            continue
        for v, rel in graph.neighbors(i)[:3]:
            dst = graph.name_of[v]
            arrow = f"—{rel.lstrip('~')}→" if not rel.startswith("~") \
                else f"←{rel.lstrip('~')}—"
            paths.append(f"{seed} {arrow} {dst}")
            for v2, rel2 in graph.neighbors(v)[:2]:
                if v2 == i:
                    continue
                a2 = f"—{rel2.lstrip('~')}→" if not rel2.startswith("~") \
                    else f"←{rel2.lstrip('~')}—"
                paths.append(f"{seed} {arrow} {dst} {a2} {graph.name_of[v2]}")
        if len(paths) >= max_paths * 4:
            break
    return paths[:max_paths * 4]
