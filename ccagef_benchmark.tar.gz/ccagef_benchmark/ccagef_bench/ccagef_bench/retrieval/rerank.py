"""Optional cross-encoder reranking of the fused pool (protocol Stage 4)."""
from __future__ import annotations

from typing import Dict, List, Tuple

Run = List[Tuple[str, float]]


class CrossEncoderReranker:
    def __init__(self, model_name: str, fp16: bool = True) -> None:
        from sentence_transformers import CrossEncoder
        import torch
        device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model = CrossEncoder(model_name, device=device, max_length=512)
        if fp16 and device == "cuda":
            self.model.model.half()

    def rerank(self, query: str, run: Run, texts: Dict[str, dict],
               depth: int = 50) -> Run:
        head, tail = run[:depth], run[depth:]
        pairs = [(query, (texts.get(eid, {}).get("text") or "")[:2000])
                 for eid, _s in head]
        if not pairs:
            return run
        scores = self.model.predict(pairs, batch_size=32,
                                    show_progress_bar=False)
        reranked = sorted(zip([e for e, _ in head], map(float, scores)),
                          key=lambda x: -x[1])
        # keep the tail after the reranked head with strictly lower scores
        floor = reranked[-1][1] if reranked else 0.0
        tail_out = [(e, floor - 1 - i) for i, (e, _s) in enumerate(tail)]
        return reranked + tail_out
