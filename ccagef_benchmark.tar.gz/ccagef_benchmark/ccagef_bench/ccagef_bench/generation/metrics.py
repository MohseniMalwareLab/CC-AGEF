"""Generation metrics (EVAL_PROTOCOL §6): citation precision/recall against
gold qrels, hallucinated-citation rate, abstention correctness."""
from __future__ import annotations

from typing import Dict, List, Optional, Set


def citation_metrics(citations: List[str], gold_grades: Dict[str, int],
                     corpus_ids: Optional[Set[str]],
                     min_grade: int = 1) -> Dict[str, Optional[float]]:
    rel = {d for d, g in gold_grades.items() if g >= min_grade}
    cited = list(dict.fromkeys(citations))       # dedup, keep order
    out: Dict[str, Optional[float]] = {}
    if cited:
        supported = sum(1 for c in cited if c in rel)
        out["CitePrecision"] = supported / len(cited)
        nonexistent = sum(1 for c in cited
                          if corpus_ids is not None and c not in corpus_ids)
        graded_zero = sum(1 for c in cited if gold_grades.get(c, None) == 0)
        # Split the two failure modes: fabricated identifiers indict the
        # generator; real-but-irrelevant citations indict evidence selection.
        out["HallucFabricated"] = nonexistent / len(cited)
        out["HallucIrrelevant"] = graded_zero / len(cited)
        out["HallucCiteRate"] = (nonexistent + graded_zero) / len(cited)
    else:
        out["CitePrecision"] = None
        out["HallucCiteRate"] = None
    out["CiteRecall"] = (sum(1 for d in rel if d in set(cited)) / len(rel)) \
        if rel else None
    return out


def abstention_metrics(results: Dict[str, dict],
                       ungrounded_qids: Set[str]) -> Dict[str, Optional[float]]:
    """results: qid -> parsed generator output. Ungrounded qids are the
    samples with no qrels in any tier (correct behavior = abstain)."""
    abstained = {q for q, r in results.items() if r.get("abstain")}
    answered = set(results) - abstained
    tp = len(abstained & ungrounded_qids)
    out: Dict[str, Optional[float]] = {}
    out["AbstainPrecision"] = tp / len(abstained) if abstained else None
    out["AbstainRecall"] = (tp / len(ungrounded_qids & set(results))) \
        if (ungrounded_qids & set(results)) else None
    out["AnswerRate"] = len(answered) / len(results) if results else None
    return out


def _norm_fn(name: str) -> str:
    return (name or "").strip().strip("()").lower()


def content_metrics(output: dict, reference: Optional[dict]
                    ) -> Dict[str, Optional[float]]:
    """Structured-field correctness against the expert reference: the two
    most falsifiable claims of an explanation, scored exactly (no judge).

    SubsysMatch  - predicted subsystem == gold_subsystem (case-insensitive).
    CulpritHit   - any predicted culprit function is in expected_functions.
    CulpritF1    - set F1 between predicted and expected functions.
    """
    out: Dict[str, Optional[float]] = {
        "SubsysMatch": None, "CulpritHit": None, "CulpritF1": None}
    if not reference or output.get("abstain") or output.get("parse_error"):
        return out
    gold_sub = _norm_fn(reference.get("gold_subsystem") or "")
    pred_sub = _norm_fn(output.get("subsystem") or "")
    if gold_sub:
        out["SubsysMatch"] = 1.0 if pred_sub == gold_sub else 0.0
    exp = {_norm_fn(f) for f in (reference.get("expected_functions") or [])
           if _norm_fn(f)}
    pred = {_norm_fn(f) for f in (output.get("culprit_functions") or [])
            if _norm_fn(f)}
    if exp:
        hit = len(exp & pred)
        out["CulpritHit"] = 1.0 if hit else 0.0
        prec = hit / len(pred) if pred else 0.0
        rec = hit / len(exp)
        out["CulpritF1"] = (2 * prec * rec / (prec + rec)) \
            if (prec + rec) else 0.0
    return out
