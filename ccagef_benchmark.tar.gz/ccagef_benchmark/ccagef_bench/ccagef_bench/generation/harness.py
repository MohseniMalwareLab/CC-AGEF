"""Evidence-conditioned generation harness (protocol Stage 6).

Uses HuggingFace transformers; 4-bit NF4 quantization by default so a 7B
coder model fits comfortably in Colab GPU memory (a 7B model in 4-bit is
~5-6 GiB; even 32B-class fits well under a 76 GiB ceiling). Closed-book mode
omits evidence — the contamination baseline required by EVAL_PROTOCOL §6.
"""
from __future__ import annotations

import json
import re
from typing import Dict, List, Optional, Sequence, Tuple

PROMPT_TEMPLATE = """You are a Linux kernel expert. Analyze the kernel crash \
below and produce a root-cause explanation grounded ONLY in the evidence \
provided. Every claim in root_cause must be supported by a cited evidence id.

ABSTENTION RULE (mandatory, checked): before answering, verify BOTH:
  (1) at least one evidence chunk contains the culprit function or the code
      path where the failure mechanism occurs, AND
  (2) the evidence supports a specific causal mechanism, not just the
      crash's symptoms.
If either check fails, you MUST output exactly:
{{"abstain": true, "reason": "<which check failed and why>"}}
Answering from background knowledge when the evidence is insufficient is an
error; abstaining in that situation is the correct, rewarded behavior.

CITATION RULE: copy evidence ids EXACTLY as printed inside [brackets],
including the channel prefix before the first colon (e.g. "code:...",
"patch:..."). Do not shorten, reformat, or invent ids.

CRASH REPORT:
{crash}

{evidence_block}{paths_block}
Respond with ONLY a JSON object, no markdown fences, with keys:
  "subsystem": one kernel subsystem label,
  "culprit_functions": list of function names appearing in the evidence,
  "root_cause": 3-6 sentences (mechanism -> trigger -> consequence -> fix),
  "mitigation": 1-3 sentences,
  "citations": list of evidence_id strings used (subset of the ids above).
"""


def build_prompt(sample: dict, evidence: Sequence[dict],
                 graph_paths: Sequence[str], closed_book: bool = False,
                 char_budget: int = 24000) -> str:
    crash = sample.get("input", {}).get("normalized_log", "")[:6000]
    if closed_book:
        ev_block = ("EVIDENCE: (none provided — answer from the crash "
                    "report alone; cite nothing)\n\n")
        paths_block = ""
    else:
        parts: List[str] = []
        used = 0
        for ch in evidence:
            body = (ch.get("text") or "")[:2500]
            entry = (f"[{ch['evidence_id']}] (channel={ch.get('channel')}, "
                     f"path={ch.get('path') or '-'}) \n{body}\n")
            if used + len(entry) > char_budget:
                break
            parts.append(entry); used += len(entry)
        ev_block = "EVIDENCE CHUNKS:\n" + "\n".join(parts) + "\n"
        paths_block = ("\nGRAPH PATHS (crash-adjacent structure):\n"
                       + "\n".join(graph_paths[:10]) + "\n\n") \
            if graph_paths else "\n"
    return PROMPT_TEMPLATE.format(crash=crash, evidence_block=ev_block,
                                  paths_block=paths_block)


def parse_output(text: str) -> dict:
    """Robustly extract the JSON object from a model response."""
    text = text.strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.M).strip()
    m = re.search(r"\{.*\}", text, flags=re.S)
    raw = m.group(0) if m else text
    try:
        obj = json.loads(raw)
    except Exception:
        return {"parse_error": True, "raw": text[:2000]}
    if obj.get("abstain"):
        return {"abstain": True, "reason": obj.get("reason", "")}
    return {
        "abstain": False,
        "subsystem": obj.get("subsystem"),
        "culprit_functions": obj.get("culprit_functions") or [],
        "root_cause": obj.get("root_cause") or "",
        "mitigation": obj.get("mitigation") or "",
        "citations": [c for c in (obj.get("citations") or [])
                      if isinstance(c, str)],
    }


class EchoGenerator:
    """Deterministic mock for pipeline smoke tests (--generator-model echo).
    Emits a valid JSON answer citing the first two evidence ids found in the
    prompt, so every downstream metric exercises real code paths on CPU."""

    def __init__(self, *_a, **_k) -> None:
        pass

    def generate(self, prompt: str) -> str:
        ids = re.findall(r"^\[([^\]]+)\] \(channel=", prompt,
                         flags=re.M)[:2]
        if not ids:
            return json.dumps({"abstain": True, "reason": "no evidence"})
        return json.dumps({
            "abstain": False, "subsystem": "net",
            "culprit_functions": ["__tun_chr_ioctl"],
            "root_cause": "echo-mode canned mechanism.",
            "mitigation": "echo-mode canned mitigation.",
            "citations": ids})


def make_generator(model_name: str, load_4bit: bool, max_new_tokens: int):
    if model_name == "echo":
        return EchoGenerator()
    return HFGenerator(model_name, load_4bit, max_new_tokens)


class HFGenerator:
    def __init__(self, model_name: str, load_4bit: bool = True,
                 max_new_tokens: int = 512) -> None:
        import torch
        from transformers import (AutoModelForCausalLM, AutoTokenizer,
                                  BitsAndBytesConfig)
        self.max_new_tokens = max_new_tokens
        self.tok = AutoTokenizer.from_pretrained(model_name)
        kwargs = dict(device_map="auto")
        if load_4bit:
            kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True, bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=torch.bfloat16)
        try:                                   # transformers >= 4.56
            self.model = AutoModelForCausalLM.from_pretrained(
                model_name, dtype=torch.bfloat16, **kwargs)
        except TypeError:                      # older versions
            self.model = AutoModelForCausalLM.from_pretrained(
                model_name, torch_dtype=torch.bfloat16, **kwargs)

    def generate(self, prompt: str) -> str:
        import torch
        msgs = [{"role": "user", "content": prompt}]
        # return_dict=True + **unpacking is correct on every transformers
        # version; newer releases return a BatchEncoding (no .shape) from
        # apply_chat_template, which breaks positional model.generate(...).
        enc = self.tok.apply_chat_template(
            msgs, add_generation_prompt=True, tokenize=True,
            return_dict=True, return_tensors="pt")
        enc = {k: v.to(self.model.device) for k, v in enc.items()}
        with torch.no_grad():
            out = self.model.generate(
                **enc, max_new_tokens=self.max_new_tokens, do_sample=False,
                pad_token_id=self.tok.pad_token_id
                or self.tok.eos_token_id)
        prompt_len = enc["input_ids"].shape[1]
        return self.tok.decode(out[0][prompt_len:],
                               skip_special_tokens=True)
