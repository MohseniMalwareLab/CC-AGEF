from __future__ import annotations

from collections import Counter
from typing import Dict, List, Optional, Sequence, Tuple


def predictions_from_run(ranked: Sequence[str], texts: Dict[str, dict],
                         top_k: int = 10) -> dict:
    fns: List[str] = []
    files: List[str] = []
    subs: List[str] = []
    for eid in ranked[:top_k]:
        meta = texts.get(eid)
        if not meta or meta.get("channel") != "code":
            continue
        if meta.get("symbol"):
            fns.append(meta["symbol"])
        if meta.get("path"):
            files.append(meta["path"])
        if meta.get("subsystem"):
            subs.append(meta["subsystem"])
    subsystem = Counter(subs).most_common(1)[0][0] if subs else None
    # de-dup preserving rank order
    seen = set(); fns = [f for f in fns if not (f in seen or seen.add(f))]
    seen = set(); files = [f for f in files if not (f in seen or seen.add(f))]
    return {"functions": fns, "files": files, "subsystem": subsystem}


def _set_f1(pred: Sequence[str], gold: Sequence[str]) -> Optional[float]:
    ps, gs = set(pred), set(gold)
    if not gs:
        return None
    if not ps:
        return 0.0
    tp = len(ps & gs)
    prec = tp / len(ps); rec = tp / len(gs)
    return 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0


def localization_metrics(pred: dict, gold_ref: dict) -> Dict[str, Optional[float]]:
    gf = gold_ref.get("expected_functions") or []
    gfl = gold_ref.get("expected_files") or []
    gsub = gold_ref.get("gold_subsystem")
    out: Dict[str, Optional[float]] = {}
    out["FnTop1"] = (1.0 if pred["functions"] and pred["functions"][0] in gf
                     else 0.0) if gf else None
    out["FnHit@10"] = (1.0 if any(f in gf for f in pred["functions"][:10])
                       else 0.0) if gf else None
    out["FnSetF1"] = _set_f1(pred["functions"][:10], gf)
    out["FileHit@10"] = (1.0 if any(f in gfl for f in pred["files"][:10])
                         else 0.0) if gfl else None
    out["FileSetF1"] = _set_f1(pred["files"][:10], gfl)
    out["SubsysAcc"] = (1.0 if pred.get("subsystem") == gsub else 0.0) \
        if gsub else None
    return out
