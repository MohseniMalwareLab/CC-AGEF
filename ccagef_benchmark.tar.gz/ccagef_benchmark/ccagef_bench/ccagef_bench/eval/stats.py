
from __future__ import annotations

import random
from collections import defaultdict
from typing import Dict, List, Optional, Tuple


def family_means(per_query: Dict[str, Optional[float]],
                 families: Dict[str, str]) -> Dict[str, float]:
    bucket: Dict[str, List[float]] = defaultdict(list)
    for qid, v in per_query.items():
        if v is None:
            continue
        bucket[families.get(qid, f"self:{qid}")].append(v)
    return {fam: sum(vs) / len(vs) for fam, vs in bucket.items() if vs}


def mean_with_ci(per_query: Dict[str, Optional[float]],
                 families: Dict[str, str], resamples: int = 1000,
                 seed: int = 7) -> Tuple[Optional[float], Optional[float],
                                         Optional[float], int]:
    """Returns (mean, ci_low, ci_high, n_families) at 95%."""
    fm = family_means(per_query, families)
    fams = sorted(fm)
    if not fams:
        return None, None, None, 0
    vals = [fm[f] for f in fams]
    point = sum(vals) / len(vals)
    rng = random.Random(seed)
    boots = []
    n = len(vals)
    for _ in range(resamples):
        s = [vals[rng.randrange(n)] for _ in range(n)]
        boots.append(sum(s) / n)
    boots.sort()
    lo = boots[int(0.025 * resamples)]
    hi = boots[min(int(0.975 * resamples), resamples - 1)]
    return point, lo, hi, n


def paired_bootstrap_p(per_query_a: Dict[str, Optional[float]],
                       per_query_b: Dict[str, Optional[float]],
                       families: Dict[str, str], resamples: int = 1000,
                       seed: int = 7) -> Tuple[Optional[float],
                                               Optional[float], int]:
    """One-sided paired bootstrap: p-value for H0 'A is not better than B'.

    Returns (delta_mean, p_value, n_paired_families).
    """
    fa = family_means(per_query_a, families)
    fb = family_means(per_query_b, families)
    common = sorted(set(fa) & set(fb))
    if not common:
        return None, None, 0
    deltas = [fa[f] - fb[f] for f in common]
    n = len(deltas)
    point = sum(deltas) / n
    rng = random.Random(seed)
    worse = 0
    for _ in range(resamples):
        s = [deltas[rng.randrange(n)] for _ in range(n)]
        if sum(s) / n <= 0:
            worse += 1
    return point, (worse + 1) / (resamples + 1), n


def holm_bonferroni(pvals: Dict[str, float], alpha: float = 0.05
                    ) -> Dict[str, bool]:
    """Holm–Bonferroni step-down; returns {name: significant}."""
    items = sorted(pvals.items(), key=lambda x: x[1])
    m = len(items)
    out: Dict[str, bool] = {}
    still = True
    for i, (name, p) in enumerate(items):
        if still and p <= alpha / (m - i):
            out[name] = True
        else:
            still = False
            out[name] = False
    return out
