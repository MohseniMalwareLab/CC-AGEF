
from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Optional, Sequence, Tuple

from ..data import channel_of


def recall_at_k(ranked: Sequence[str], grades: Dict[str, int],
                k: int, min_grade: int) -> Optional[float]:
    rel = {d for d, g in grades.items() if g >= min_grade}
    if not rel:
        return None                     # undefined for this query
    hit = sum(1 for d in ranked[:k] if d in rel)
    return hit / len(rel)


def precision_at_k(ranked: Sequence[str], grades: Dict[str, int],
                   k: int, min_grade: int) -> Optional[float]:
    if not any(g >= min_grade for g in grades.values()):
        return None
    rel = {d for d, g in grades.items() if g >= min_grade}
    return sum(1 for d in ranked[:k] if d in rel) / k


def mrr(ranked: Sequence[str], grades: Dict[str, int],
        min_grade: int) -> Optional[float]:
    rel = {d for d, g in grades.items() if g >= min_grade}
    if not rel:
        return None
    for i, d in enumerate(ranked):
        if d in rel:
            return 1.0 / (i + 1)
    return 0.0


def ndcg_at_k(ranked: Sequence[str], grades: Dict[str, int],
              k: int) -> Optional[float]:
    if not any(g > 0 for g in grades.values()):
        return None
    dcg = 0.0
    for i, d in enumerate(ranked[:k]):
        g = grades.get(d, 0)
        if g > 0:
            dcg += (2 ** g - 1) / math.log2(i + 2)
    ideal = sorted((g for g in grades.values() if g > 0), reverse=True)[:k]
    idcg = sum((2 ** g - 1) / math.log2(i + 2) for i, g in enumerate(ideal))
    return dcg / idcg if idcg > 0 else None


def bpref(ranked: Sequence[str], grades: Dict[str, int],
          min_grade: int) -> Optional[float]:
    """Judged-only preference metric (Buckley & Voorhees 2004), robust to
    shallow pools: unjudged retrieved docs are skipped, not penalised."""
    R = {d for d, g in grades.items() if g >= min_grade}
    N = {d for d, g in grades.items() if g < min_grade}
    if not R:
        return None
    denom_R = len(R)
    seen_nonrel = 0
    total = 0.0
    for d in ranked:
        if d in R:
            total += 1.0 - min(seen_nonrel, denom_R) / min(len(N) or 1,
                                                           denom_R) \
                if N else 1.0
        elif d in N:
            seen_nonrel += 1
        # unjudged: skip entirely
    return total / denom_R


def unjudged_at_k(ranked: Sequence[str], grades: Dict[str, int],
                  k: int) -> float:
    if not ranked:
        return 0.0
    top = ranked[:k]
    return sum(1 for d in top if d not in grades) / len(top)


def per_channel_recall_at_k(ranked: Sequence[str], grades: Dict[str, int],
                            k: int, min_grade: int
                            ) -> Dict[str, Optional[float]]:
    rel_by_ch: Dict[str, set] = defaultdict(set)
    for d, g in grades.items():
        if g >= min_grade:
            rel_by_ch[channel_of(d)].add(d)
    out: Dict[str, Optional[float]] = {}
    topset = set(ranked[:k])
    for ch, rel in rel_by_ch.items():
        out[ch] = len(rel & topset) / len(rel)
    return out


def r_precision(ranked: Sequence[str], grades: Dict[str, int],
                min_grade: int) -> Optional[float]:
    """|rel ∩ top-R| / R with R = |rel|; depth-fair when |rel| is large
    (strict qrels average ~127 relevant/query, so Recall@20 is ceiling-
    bounded at ~20/|rel| — R-Precision is not)."""
    rel = {d for d, g in grades.items() if g >= min_grade}
    if not rel:
        return None
    R = len(rel)
    return sum(1 for d in ranked[:R] if d in rel) / R
