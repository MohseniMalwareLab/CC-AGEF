from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from ..config import BenchConfig
from . import trec
from .stats import mean_with_ci, paired_bootstrap_p, holm_bonferroni

Run = Dict[str, List[Tuple[str, float]]]          # qid -> ranked (doc, score)
Qrels = Dict[str, Dict[str, int]]

TIER_METRICS = {
    "strict": ["recall", "rprec", "per_channel_recall", "ndcg", "mrr"],
    "silver": ["recall", "rprec", "per_channel_recall", "ndcg", "mrr"],
    "gold":   ["ndcg", "mrr", "precision", "bpref", "unjudged"],
}

TIER_MIN_GRADE_ATTR = {"strict": "strict_min_grade",
                       "silver": "silver_min_grade",
                       "gold": "gold_relevant_min_grade"}


def _ranked_ids(run: Run, qid: str) -> List[str]:
    return [d for d, _s in run.get(qid, [])]


def evaluate_run_on_tier(run: Run, qrels: Qrels, tier: str,
                         cfg: BenchConfig, qids: List[str]
                         ) -> Dict[str, Dict[str, Optional[float]]]:
    """Per-query metric values for one (run, tier). Returns
    {metric_name: {qid: value_or_None}} — protocol-legal metrics only."""
    if tier not in TIER_METRICS:
        raise ValueError(f"unknown tier {tier}")
    allowed = TIER_METRICS[tier]
    min_grade = getattr(cfg, TIER_MIN_GRADE_ATTR[tier],
                        cfg.strict_min_grade)
    out: Dict[str, Dict[str, Optional[float]]] = {}

    def col(name: str) -> Dict[str, Optional[float]]:
        return out.setdefault(name, {})

    for qid in qids:
        grades = qrels.get(qid, {})
        ranked = _ranked_ids(run, qid)
        if "recall" in allowed:
            for k in cfg.recall_ks:
                col(f"Recall@{k}")[qid] = trec.recall_at_k(
                    ranked, grades, k, min_grade)
        if "per_channel_recall" in allowed:
            per_ch = trec.per_channel_recall_at_k(
                ranked, grades, max(cfg.recall_ks), min_grade)
            for ch, v in per_ch.items():
                col(f"ChRecall@{max(cfg.recall_ks)}[{ch}]")[qid] = v
        if "rprec" in allowed:
            col("RPrec")[qid] = trec.r_precision(ranked, grades, min_grade)
        if "ndcg" in allowed:
            col(f"nDCG@{cfg.ndcg_k}")[qid] = trec.ndcg_at_k(
                ranked, grades, cfg.ndcg_k)
        if "mrr" in allowed:
            col("MRR")[qid] = trec.mrr(ranked, grades, min_grade)
        if "precision" in allowed:
            for k in cfg.precision_ks:
                col(f"P@{k}")[qid] = trec.precision_at_k(
                    ranked, grades, k, min_grade)
        if "bpref" in allowed:
            col("bpref")[qid] = trec.bpref(ranked, grades, min_grade)
        if "unjudged" in allowed:
            col(f"Unjudged@{cfg.unjudged_k}")[qid] = trec.unjudged_at_k(
                ranked, grades, cfg.unjudged_k)
    return out


def summarize(per_query_by_metric: Dict[str, Dict[str, Optional[float]]],
              families: Dict[str, str], cfg: BenchConfig
              ) -> Dict[str, dict]:
    rows: Dict[str, dict] = {}
    for metric, pq in per_query_by_metric.items():
        mean, lo, hi, n = mean_with_ci(pq, families,
                                       cfg.bootstrap_resamples,
                                       cfg.bootstrap_seed)
        rows[metric] = {"mean": mean, "ci_low": lo, "ci_high": hi,
                        "n_families": n}
    return rows


def significance_vs_baseline(
        systems_pq: Dict[str, Dict[str, Dict[str, Optional[float]]]],
        baseline: str, metric: str, families: Dict[str, str],
        cfg: BenchConfig) -> Dict[str, dict]:
    """Paired bootstrap of every system vs `baseline` on `metric`, with
    Holm–Bonferroni across the comparisons in this table."""
    base_pq = systems_pq[baseline].get(metric, {})
    raw: Dict[str, Tuple[Optional[float], Optional[float], int]] = {}
    for name, metrics in systems_pq.items():
        if name == baseline or metric not in metrics:
            continue
        raw[name] = paired_bootstrap_p(metrics[metric], base_pq, families,
                                       cfg.bootstrap_resamples,
                                       cfg.bootstrap_seed)
    pvals = {n: v[1] for n, v in raw.items() if v[1] is not None}
    sig = holm_bonferroni(pvals) if pvals else {}
    return {n: {"delta": v[0], "p": v[1], "n_families": v[2],
                "significant_holm": sig.get(n)}
            for n, v in raw.items()}


# ------------------------------------------------------------------ report --

def write_report(out_dir: str, tier: str,
                 summaries: Dict[str, Dict[str, dict]],
                 sig: Optional[Dict[str, Dict[str, dict]]] = None) -> str:
    """summaries: {system: {metric: {mean, ci_low, ci_high, n_families}}}"""
    outp = Path(out_dir); outp.mkdir(parents=True, exist_ok=True)
    csv_path = outp / f"table_{tier}.csv"
    metrics = sorted({m for s in summaries.values() for m in s})
    with open(csv_path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["system"] + [f"{m} (95% CI)" for m in metrics])
        for sysname in sorted(summaries):
            row = [sysname]
            for m in metrics:
                cell = summaries[sysname].get(m)
                if not cell or cell.get("mean") is None:
                    row.append("-")
                elif cell.get("ci_low") is None or cell.get("ci_high") is None:
                    # aggregate metrics (e.g. abstention rates) have no CI
                    row.append("%.4f" % cell["mean"])
                else:
                    row.append("%.4f [%.4f, %.4f]" %
                               (cell["mean"], cell["ci_low"], cell["ci_high"]))
            w.writerow(row)
    if sig:
        with open(outp / f"significance_{tier}.json", "w") as fh:
            json.dump(sig, fh, indent=2)
    md = [f"# {tier} tier results\n", "| system | " +
          " | ".join(metrics) + " |",
          "|" + "---|" * (len(metrics) + 1)]
    for sysname in sorted(summaries):
        cells = []
        for m in metrics:
            cell = summaries[sysname].get(m)
            cells.append("%.3f" % cell["mean"]
                         if cell and cell["mean"] is not None else "-")
        md.append(f"| {sysname} | " + " | ".join(cells) + " |")
    (outp / f"table_{tier}.md").write_text("\n".join(md))
    return str(csv_path)
